---
name: synomic-design
description: Use this skill to generate well-branded interfaces and assets for Synomic — a Frisian ZZP-onderneming on the intersection of finance, IT and AI-automatisering. Contains essential design guidelines, colors, type, fonts, assets, and UI-kit components for production code or throwaway prototypes.
user-invocable: true
---

# Synomic — design skill

Read `readme.md` in this skill first; it covers the brand context, content fundamentals (Dutch, formal "u", nuchter tone) and visual foundations (navy + cyan, Syne / DM Sans, navy-tinted shadows, no SVG icon font).

Then explore as you need:

- `styles.css` and the `tokens/` directory — drop these into a project to get the brand's palette, fonts, spacing and motion tokens.
- `components/` — React primitives, organised by group (`core`, `forms`, `navigation`, `marketing`). Each component has a `.d.ts` (props) and a `.prompt.md` (when to use, example usage).
- `ui_kits/synomic-website/` — interactive recreation of all six pages of synomic.nl. Read `screens.jsx` to see how the components compose into real layouts.
- `templates/landing-page/` — a Synomic-style landing-page scaffold; copy it for a fresh page.
- `assets/` — logos and partner marks. Copy out, don't inline as base64.
- `guidelines/` — foundation specimen cards (colors, type, spacing). Useful for visual reference.

## When invoked

If creating **visual artifacts** (slides, mocks, throwaway prototypes), copy assets and tokens into a new project, then build static HTML for the user to view. Match the brand voice — Dutch, formal, nuchter; cyan accents earned, never sprayed.

If working on **production code**, link `styles.css` from this skill (or copy `tokens/` and the components you need) and use the components as documented.

If the user invokes this skill without further guidance, ask what they want to build — a deck, a landing page, an internal tool, a one-off mock — and any constraints (specific page, target audience, length). Then act as an expert designer and write HTML, JSX, or both, depending on the need.

## Don't

- Don't introduce a third accent colour. Cyan is the only one.
- Don't use Heroicons / Lucide / Font Awesome / Material icons — Synomic has no icon font. Use emoji inline or a labelled button instead. Ask before adding any new icon system.
- Don't invent stock photography or hand-drawn illustrations. The brand has no imagery on its site; if imagery is needed, ask the user to provide it.
- Don't write English marketing-speak. Dutch, formal-u, third-person ("Synomic doet…").
