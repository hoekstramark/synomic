Dark navy page header used at the top of every inner page (over-ons, diensten, projecten, contact).

```jsx
<PageHeader
  title="Neem"
  cyanWord="contact op"
  breadcrumb={[{ href: 'index.html', label: 'Home' }, { label: 'Contact' }]}
  intro="Heeft u een vraag of wilt u een vrijblijvend gesprek? Berichten worden binnen 1 werkdag beantwoord."
/>
```
