import * as React from 'react';

export interface BreadcrumbItem { href?: string; label: React.ReactNode }

/** Crumb row inside the dark page-header. Last item has no link and reads white. */
export interface BreadcrumbProps {
  items: BreadcrumbItem[];
  style?: React.CSSProperties;
}

export function Breadcrumb(props: BreadcrumbProps): JSX.Element;
