/**
 * Footer — three-column dark footer.
 *
 * Always rendered with logo+address on the left and 1–N link columns on the
 * right. Bottom strip shows copyright and a "Gebouwd met ♥ in Nederland" line.
 *
 * The wordmark inverts via `filter: brightness(0) invert(1)` — pass the
 * standard `assets/logo-white.png` (the inversion still works on dark navy
 * with the white logo).
 */
export function Footer({
  logoSrc,
  brand = {
    name: 'Synomic',
    lines: ['Koornbeursweg 73', '8442 DJ Heerenveen', 'KVK: 94705569'],
  },
  columns = [
    { title: 'Navigatie', links: [
      { href: 'index.html',     label: 'Home' },
      { href: 'over-ons.html',  label: 'Over ons' },
      { href: 'diensten.html',  label: 'Diensten' },
      { href: 'projecten.html', label: 'Projecten' },
      { href: 'partners.html',  label: 'Partners' },
      { href: 'contact.html',   label: 'Contact' },
    ]},
    { title: 'Diensten', links: [
      { href: 'diensten.html', label: 'Finance & Data' },
      { href: 'diensten.html', label: 'IT Automatisering' },
      { href: 'diensten.html', label: 'AI Toepassingen' },
      { href: 'diensten.html', label: 'Procesoptimalisatie' },
    ]},
  ],
  copyright = '© 2025 Synomic – KVK 94705569. Alle rechten voorbehouden.',
  signoff = 'Gebouwd met ♥ in Nederland',
  style,
}) {
  const wrap = {
    background: 'var(--surface-dark)',
    color: 'var(--text-on-dark-mid)',
    padding: '64px var(--page-pad-x) 36px',
    fontFamily: 'var(--font-body)',
    ...style,
  };
  const top = {
    display: 'grid',
    gridTemplateColumns: '1.4fr 1fr 1fr',
    gap: 48,
    paddingBottom: 48,
    borderBottom: 'var(--border-on-dark) 1px solid',
    marginBottom: 32,
  };
  const brandLines = {
    fontSize: '.87rem', color: 'var(--text-on-dark-low)', lineHeight: 'var(--lh-loose)',
  };
  const brandName = {
    fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1rem',
    color: 'var(--text-on-dark)', marginBottom: 8, marginTop: 14,
  };
  const colH = {
    fontFamily: 'var(--font-display)', fontSize: '.9rem', fontWeight: 700,
    color: 'var(--text-on-dark)', letterSpacing: 'var(--ls-wide)',
    textTransform: 'uppercase', marginBottom: 18,
  };
  const liStyle = { marginBottom: 10, listStyle: 'none' };
  const linkStyle = { fontSize: '.88rem', color: 'var(--text-on-dark-mid)', transition: 'color var(--dur-fast)' };
  const bottom = {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    fontSize: '.82rem', flexWrap: 'wrap', gap: 12,
  };

  return React.createElement(
    'footer', { className: 'syn-footer', style: wrap },
    React.createElement(
      'div', { style: top },
      React.createElement(
        'div', { className: 'syn-footer-brand' },
        logoSrc
          ? React.createElement('img', {
              src: logoSrc,
              alt: brand.name,
              style: { height: 34, filter: 'brightness(0) invert(1)' },
            })
          : null,
        React.createElement('div', { style: brandName }, brand.name),
        React.createElement('div', { style: brandLines }, ...brand.lines.flatMap((l, i) => i === 0 ? [l] : [React.createElement('br', { key: i }), l]))
      ),
      ...columns.map((col, i) =>
        React.createElement(
          'div', { key: i, className: 'syn-footer-col' },
          React.createElement('h4', { style: colH }, col.title),
          React.createElement(
            'ul', { style: { listStyle: 'none', margin: 0, padding: 0 } },
            ...col.links.map((l, j) =>
              React.createElement(
                'li', { key: j, style: liStyle },
                React.createElement('a', { href: l.href, style: linkStyle }, l.label)
              )
            )
          )
        )
      )
    ),
    React.createElement(
      'div', { style: bottom },
      React.createElement('span', null, copyright),
      React.createElement('span', null, signoff)
    )
  );
}
