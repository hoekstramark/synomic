/**
 * NavBar — Synomic's top navigation.
 *
 * A 72px fixed bar with the logo on the left, an inline link list in the
 * middle, and the "Contact" CTA pill on the right. Two appearance modes:
 *
 *   • light  — translucent white, hairline border. Used on inner pages.
 *   • dark   — solid navy with white-translucent links. Used on the homepage
 *              so the bar reads against the hero gradient seamlessly.
 *
 * Pass `active` to mark which item is current; that item gets the cyan
 * accent underline drawn by `::after`.
 *
 * The component is presentation-only — it does NOT implement the hamburger /
 * scroll-shadow JS, because consumers may want to handle that. Add
 * `is-scrolled` to the root manually when you implement scroll behaviour.
 */
export function NavBar({
  items = [
    { href: 'index.html',     label: 'Home' },
    { href: 'over-ons.html',  label: 'Over ons' },
    { href: 'diensten.html',  label: 'Diensten' },
    { href: 'projecten.html', label: 'Projecten' },
    { href: 'partners.html',  label: 'Partners' },
  ],
  cta = { href: 'contact.html', label: 'Contact' },
  active = 'index.html',
  logoSrc,
  tone = 'light',
  style,
}) {
  const isDark = tone === 'dark';
  const wrap = {
    position: 'sticky',
    top: 0,
    zIndex: 100,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 var(--page-pad-x)',
    height: 72,
    background: isDark
      ? 'var(--color-navy)'
      : 'rgba(255,255,255,0.95)',
    backdropFilter: isDark ? undefined : 'blur(12px)',
    borderBottom: isDark
      ? '1px solid rgba(255,255,255,.08)'
      : '1px solid rgba(221,227,236,.6)',
    boxShadow: 'var(--shadow-sm)',
    ...style,
  };
  const linkColor = isDark ? 'rgba(255,255,255,.8)' : 'var(--text-strong)';
  const linkList = {
    display: 'flex', gap: 'var(--gap-nav)', listStyle: 'none', alignItems: 'center', margin: 0, padding: 0,
  };
  const linkStyle = (isActive) => ({
    fontFamily: 'var(--font-body)',
    fontWeight: 500,
    fontSize: '.95rem',
    color: isActive ? 'var(--color-cyan)' : linkColor,
    letterSpacing: '.02em',
    paddingBottom: 3,
    position: 'relative',
    borderBottom: isActive ? '2px solid var(--color-cyan)' : '2px solid transparent',
    transition: 'color var(--dur-fast)',
  });
  const ctaStyle = {
    background: 'var(--color-cyan)',
    color: 'var(--text-on-dark)',
    padding: 'var(--pad-btn-sm)',
    borderRadius: 'var(--radius-sm)',
    fontFamily: 'var(--font-body)',
    fontWeight: 700,
    fontSize: '.95rem',
    transition: 'background var(--dur-fast), transform var(--dur-fast)',
  };

  return React.createElement(
    'nav', { className: 'syn-nav', style: wrap },
    React.createElement(
      'a', { className: 'syn-nav-logo', href: items[0].href, style: { display: 'flex', alignItems: 'center' } },
      logoSrc
        ? React.createElement('img', {
            src: logoSrc,
            alt: 'Synomic',
            style: { height: 38, display: 'block' },
          })
        : React.createElement('span', { style: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem', color: isDark ? '#fff' : 'var(--color-navy)' } }, 'synomic')
    ),
    React.createElement(
      'ul', { className: 'syn-nav-links', style: linkList },
      ...items.map((it) =>
        React.createElement(
          'li', { key: it.href },
          React.createElement('a', { href: it.href, style: linkStyle(it.href === active) }, it.label)
        )
      ),
      cta
        ? React.createElement(
            'li', { key: '__cta' },
            React.createElement('a', { href: cta.href, style: ctaStyle, className: 'syn-nav-cta' }, cta.label)
          )
        : null
    )
  );
}
