/**
 * Breadcrumb — used inside the dark .page-header strip on inner pages.
 * Cyan link → translucent-white slash → current title in translucent-white.
 */
export function Breadcrumb({ items = [], style }) {
  const wrap = {
    display: 'flex',
    gap: 8,
    alignItems: 'center',
    fontFamily: 'var(--font-body)',
    fontSize: '.84rem',
    color: 'var(--text-on-dark-low)',
    marginBottom: 20,
    ...style,
  };
  const linkStyle = { color: 'var(--color-cyan)', textDecoration: 'none' };
  const sepStyle = { color: 'rgba(255,255,255,.35)' };

  const out = [];
  items.forEach((it, i) => {
    const last = i === items.length - 1;
    if (it.href && !last) {
      out.push(React.createElement('a', { key: 'l' + i, href: it.href, style: linkStyle }, it.label));
    } else {
      out.push(React.createElement('span', { key: 'l' + i }, it.label));
    }
    if (!last) out.push(React.createElement('span', { key: 's' + i, style: sepStyle }, '/'));
  });

  return React.createElement('div', { className: 'syn-breadcrumb', style: wrap }, ...out);
}
