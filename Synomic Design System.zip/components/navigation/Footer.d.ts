import * as React from 'react';

export interface FooterLink { href: string; label: React.ReactNode }
export interface FooterColumn { title: React.ReactNode; links: FooterLink[] }
export interface FooterBrand { name: string; lines: string[] }

/** Three-column dark footer with logo, address, link columns, and a bottom copyright row. */
export interface FooterProps {
  logoSrc?: string;
  brand?: FooterBrand;
  columns?: FooterColumn[];
  copyright?: React.ReactNode;
  signoff?: React.ReactNode;
  style?: React.CSSProperties;
}

export function Footer(props: FooterProps): JSX.Element;
