import * as React from 'react';

export interface NavItem { href: string; label: string }

/**
 * NavBar — top navigation bar — fixed, 72px tall. Light on inner pages, dark navy on home.
 */
export interface NavBarProps {
  /** Link items in order. */
  items?: NavItem[];
  /** Right-side pill CTA (set null to omit). Defaults to "Contact". */
  cta?: NavItem | null;
  /** href of the active item (gets the cyan underline). */
  active?: string;
  /** Logo image src — pass the relative path to `assets/logo.png` or `logo-white.png`. */
  logoSrc?: string;
  /** light (inner pages) or dark (home page, sits over the navy hero). */
  tone?: 'light' | 'dark';
  style?: React.CSSProperties;
}

export function NavBar(props: NavBarProps): JSX.Element;
