Synomic's three-column dark footer. Sensible defaults are baked in (KVK address, full nav).

```jsx
<Footer logoSrc="assets/logo-white.png" />
```

Override columns or copyright for a specific surface; the structure stays the same.
