Fixed top nav. Light on inner pages; dark navy on the home page so it sits over the hero gradient.

```jsx
<NavBar
  tone="dark"
  logoSrc="assets/logo-white.png"
  active="index.html"
/>

<NavBar
  logoSrc="assets/logo.png"
  active="diensten.html"
/>
```

This component renders presentation only. Wire scroll-shadow / hamburger behaviour in the consuming page if you need it — the underlying CSS hooks (`.syn-nav.is-scrolled`) are intentional.
