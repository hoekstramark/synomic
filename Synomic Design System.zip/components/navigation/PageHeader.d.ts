import * as React from 'react';
import { BreadcrumbItem } from './Breadcrumb';

/**
 * Inner-page dark header. Renders breadcrumb + H1 + lede on top of the
 * navy gradient with a cyan corner glow.
 */
export interface PageHeaderProps {
  title: React.ReactNode;
  /** Single highlight word/phrase rendered in cyan after the title. */
  cyanWord?: React.ReactNode;
  breadcrumb?: BreadcrumbItem[];
  intro?: React.ReactNode;
  style?: React.CSSProperties;
}

export function PageHeader(props: PageHeaderProps): JSX.Element;
