Used inside the dark `<PageHeader>` only — the cyan link → "/" → current-page pattern.

```jsx
<Breadcrumb items={[
  { href: 'index.html', label: 'Home' },
  { label: 'Diensten' },
]} />
```
