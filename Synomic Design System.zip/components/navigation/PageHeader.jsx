/**
 * PageHeader — the dark navy strip with breadcrumb + page title that opens
 * every inner page on the site (over-ons, diensten, projecten, contact).
 *
 * Has a soft cyan radial glow in the bottom-right corner.
 *
 * The title accepts an optional `<em>cyan span</em>` — use the `cyanWord`
 * prop for that segment, or pass JSX into `title` directly.
 */
export function PageHeader({ title, cyanWord, breadcrumb, intro, style }) {
  const wrap = {
    padding: '130px var(--page-pad-x) 60px',
    background: 'var(--gradient-header)',
    position: 'relative',
    overflow: 'hidden',
    ...style,
  };
  const orb = {
    content: '""', position: 'absolute', bottom: -40, right: 0,
    width: 300, height: 300, borderRadius: '50%',
    background: 'radial-gradient(circle, var(--cyan-15) 0%, transparent 70%)',
    pointerEvents: 'none',
  };
  const h1 = {
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 'var(--fz-h1)',
    color: 'var(--text-on-dark)',
    lineHeight: 'var(--lh-display)',
  };
  const accent = { color: 'var(--color-cyan)' };
  const p = {
    fontSize: 'var(--fz-7)',
    color: 'var(--text-on-dark-mid)',
    maxWidth: 560,
    marginTop: 14,
    fontFamily: 'var(--font-body)',
  };

  return React.createElement(
    'div', { className: 'syn-page-header', style: wrap },
    React.createElement('div', { style: orb, 'aria-hidden': true }),
    breadcrumb ? React.createElement(window.SynomicDesignSystem_d4bf5f.Breadcrumb, { items: breadcrumb }) : null,
    React.createElement(
      'h1', { style: h1 },
      title,
      cyanWord ? React.createElement(React.Fragment, null, ' ', React.createElement('span', { style: accent }, cyanWord)) : null
    ),
    intro ? React.createElement('p', { style: p }, intro) : null
  );
}
