/**
 * Tag — small uppercase capsule.
 *
 * Always rendered with cyan tint background and cyan text, uppercase, .06em
 * tracking. Used everywhere the brand calls a categorical chip — service tags
 * on project cards, technology tags, "Dienst 01"-style numbering, hero badges.
 *
 * Optional `tone="muted"` swaps the cyan for muted neutrals — used for tech-stack
 * tags on the project card footer.
 */
export function Tag({ children, tone = 'cyan', style, ...rest }) {
  const tones = {
    cyan: {
      background: 'var(--cyan-10)',
      color: 'var(--color-cyan)',
    },
    muted: {
      background: 'transparent',
      color: 'var(--text-muted)',
      padding: 0,
    },
  };
  const s = {
    display: 'inline-block',
    padding: tone === 'muted' ? 0 : 'var(--pad-tag)',
    borderRadius: 'var(--radius-pill)',
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--fz-1)',
    fontWeight: 700,
    letterSpacing: 'var(--ls-wide)',
    textTransform: 'uppercase',
    ...tones[tone],
    ...style,
  };
  return React.createElement('span', { className: 'syn-tag', style: s, ...rest }, children);
}
