Hero eyebrow capsule. Renders cyan-on-cyan-tinted with a pulsing dot. Use on dark backdrops only — the contrast collapses on white.

```jsx
<Badge>Finance · IT · AI Automatisering</Badge>
<Badge dot={false}>Klaar voor de volgende stap?</Badge>
```
