The 16/20px-radius white card that holds nearly every block on the site. Pick the variant from context:

```jsx
<Card><h3>Finance & Data</h3><p>…</p></Card>                            // default
<Card variant="light"><h3>Procesoptimalisatie</h3><p>…</p></Card>      // softer
<Card variant="dark"><Stat n="30+" label="Projecten" /></Card>          // on light section
<Card variant="form"><form>…</form></Card>                              // contact form
```

The default variant gets a cyan→navy gradient top-border accent on hover plus a -5px lift; suppress with `interactive={false}` for static layouts (e.g. inside a CTA banner).
