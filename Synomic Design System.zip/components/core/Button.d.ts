import * as React from 'react';

/**
 * Primary CTA or secondary outline button — Synomic's two stock buttons.
 */
export interface ButtonProps {
  /** Visual treatment — primary fills with cyan + glow shadow; outline reads on dark only. */
  variant?: 'primary' | 'outline';
  /** What element to render as. Defaults to `<a>` because most buttons are links on Synomic. */
  as?: 'a' | 'button';
  /** href when `as="a"` (default). */
  href?: string;
  /** type when `as="button"`. */
  type?: 'button' | 'submit' | 'reset';
  /** Disable interactivity and dim to 0.55 opacity. */
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function Button(props: ButtonProps): JSX.Element;
