import * as React from 'react';

/** Hero/banner eyebrow capsule with a pulsing cyan dot. Dark backdrops only. */
export interface BadgeProps {
  /** Show the pulsing 7px cyan dot at the start (default true). */
  dot?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function Badge(props: BadgeProps): JSX.Element;
