import * as React from 'react';

/** Big-number + label pair. Inside dark panels (tone="dark") or light cards (tone="light"). */
export interface StatProps {
  /** The number, e.g. "30+", "94%", "ZZP & MKB". */
  n: React.ReactNode;
  /** Small caption below. */
  label: React.ReactNode;
  /** Optional cyan-tinted trailing span (e.g. the "+" in "30+"). */
  accent?: React.ReactNode;
  tone?: 'dark' | 'light';
  size?: 'sm' | 'md' | 'lg';
  style?: React.CSSProperties;
}

export function Stat(props: StatProps): JSX.Element;
