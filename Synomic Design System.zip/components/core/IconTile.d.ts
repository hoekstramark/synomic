import * as React from 'react';

/** Cyan-tinted square that holds a single emoji or small icon. */
export interface IconTileProps {
  /** 44px (contact-detail) or 54px (feature card). */
  size?: 'sm' | 'md';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function IconTile(props: IconTileProps): JSX.Element;
