import * as React from 'react';

/** Synomic's 16/20px-radius card. Four variants cover the entire site. */
export interface CardProps {
  /**
   * default — service tiles, project cards (interactive lift + top-border accent on hover).
   * light   — feature cards on light sections (softer border, smaller hover).
   * dark    — navy-gradient stat panel for over-ons / CTA decks.
   * form    — contact form container (20px radius, shadow-md, deeper padding).
   */
  variant?: 'default' | 'light' | 'dark' | 'form';
  /** Override the default hover-lift behaviour. */
  interactive?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function Card(props: CardProps): JSX.Element;
