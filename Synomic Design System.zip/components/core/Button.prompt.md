Synomic's stock button. Use **`variant="primary"`** for the page's main CTA — solid cyan with the signature glow shadow. Use **`variant="outline"`** only on the dark hero / CTA banner backdrops, never on white.

```jsx
<Button href="/contact">Stuur een bericht →</Button>
<Button variant="outline" href="/diensten">Bekijk diensten</Button>
```

Both render as `<a>` by default because most Synomic CTAs are anchor links. Pass `as="button"` (and `type`) for form submits.
