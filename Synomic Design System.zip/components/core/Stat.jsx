/**
 * Stat — the big-number + small-label pair Synomic uses inside dark panels
 * and the hero-stats strip.
 *
 * Two tones:
 *   • dark  — cyan number, translucent-white label (the over-ons KVK widget,
 *             hero stat strip).
 *   • light — navy number with optional cyan accent span, muted label
 *             (.stat-block on light sections).
 *
 * Optional `accent` slot wraps the trailing portion of the number in cyan
 * (e.g. "30<span>+</span>").
 */
export function Stat({ n, label, accent, tone = 'dark', size = 'md', style }) {
  const sizes = {
    sm: { num: 'var(--fz-stat)',   label: 'var(--fz-3)' },     /* hero-stats */
    md: { num: '1.6rem',           label: 'var(--fz-3)' },     /* over-ons */
    lg: { num: 'var(--fz-stat-l)', label: 'var(--fz-4)' },     /* stat-block */
  };

  const tones = {
    dark:  { numColor: 'var(--color-cyan)',  labelColor: 'var(--text-on-dark-low)' },
    light: { numColor: 'var(--text-strong)', labelColor: 'var(--text-muted)' },
  };

  const numStyle = {
    fontFamily: 'var(--font-display)',
    fontWeight: 800,
    fontSize: sizes[size].num,
    lineHeight: 1,
    color: tones[tone].numColor,
  };
  const labelStyle = {
    fontFamily: 'var(--font-body)',
    fontSize: sizes[size].label,
    color: tones[tone].labelColor,
    marginTop: 4,
  };
  const accentStyle = { color: 'var(--color-cyan)' };

  return React.createElement(
    'div',
    { className: 'syn-stat', style: style },
    React.createElement(
      'div',
      { style: numStyle },
      n,
      accent ? React.createElement('span', { style: accentStyle }, accent) : null
    ),
    React.createElement('div', { style: labelStyle }, label)
  );
}
