import * as React from 'react';

/** Small uppercase capsule. Categorical chips: service area, tech, "Dienst 01". */
export interface TagProps {
  /** Cyan-tinted capsule (default) or plain muted text for tech stacks. */
  tone?: 'cyan' | 'muted';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function Tag(props: TagProps): JSX.Element;
