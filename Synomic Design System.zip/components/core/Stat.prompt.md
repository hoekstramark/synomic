Big-number + small-label pair. Synomic uses this everywhere there's a metric or KVK fact.

```jsx
<Stat n="30" accent="+" label="Projecten" />
<Stat n="94%" label="Forecast accuracy" tone="light" size="lg" />
```

`tone="dark"` (default) renders cyan-on-translucent-white — sits inside a `<Card variant="dark">`. `tone="light"` is for stat-block tiles on a white section.
