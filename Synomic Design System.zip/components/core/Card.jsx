/**
 * Card — the 16px-radius white card.
 *
 * Used everywhere: service tiles, project cards, kernwaarden, KVK info block,
 * form card.
 *
 * Variants:
 *   • default — 1px border, 16px radius, lifts -5px on hover with a gradient
 *               top-border accent that fades in. Used for service tiles.
 *   • light   — softer border, no gradient accent. Used for "Novictus-inspired"
 *               feature cards.
 *   • dark    — navy gradient background, reverses text colors. Used for stats
 *               panels inside light sections (e.g. over-ons KVK widget).
 *   • form    — larger 20px radius, deeper padding, navy shadow. Contact form.
 *
 * `interactive` toggles the hover lift + gradient bar (default true).
 */
export function Card({
  variant = 'default',
  interactive,
  children,
  style,
  ...rest
}) {
  const wantInteractive = interactive ?? (variant === 'default' || variant === 'light');

  const variants = {
    default: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-2xl)',
      padding: 'var(--pad-card)',
    },
    light: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-soft)',
      borderRadius: 'var(--radius-2xl)',
      padding: 'var(--pad-card)',
    },
    dark: {
      background: 'linear-gradient(135deg, var(--color-navy), var(--color-navy-mid))',
      border: 'none',
      borderRadius: 'var(--radius-3xl)',
      padding: '48px 40px',
      color: 'var(--text-on-dark)',
    },
    form: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-3xl)',
      padding: 'var(--pad-card-form)',
      boxShadow: 'var(--shadow-md)',
    },
  };

  const s = {
    position: 'relative',
    overflow: 'hidden',
    transition: wantInteractive
      ? 'transform var(--dur-base), box-shadow var(--dur-base), border-color var(--dur-base)'
      : undefined,
    ...variants[variant],
    ...style,
  };

  return React.createElement(
    'div',
    {
      className: 'syn-card syn-card-' + variant + (wantInteractive ? ' is-interactive' : ''),
      style: s,
      ...rest,
    },
    children
  );
}
