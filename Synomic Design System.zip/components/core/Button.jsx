/**
 * Button — Synomic's two button shapes.
 *
 * Two variants:
 *   • primary  — solid cyan fill with cyan glow shadow, lifts -2px on hover.
 *                Used for the page's main CTA.
 *   • outline  — transparent with a 2px translucent-white border. Reads on
 *                dark backdrops only (hero, CTA banner). Border picks up
 *                cyan on hover.
 *
 * Both use the Syne display face at 600/700 — buttons look slightly typographic
 * because Syne reads more "brand" than DM Sans would.
 *
 * Sizes are intentionally not exposed — Synomic uses one button size for primary
 * CTAs and one for the smaller nav CTA / filter pills (see NavBar / Tag).
 */
export function Button({
  variant = 'primary',
  as: Tag = 'a',
  href,
  type,
  disabled = false,
  onClick,
  children,
  style,
  ...rest
}) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    fontSize: '.95rem',
    letterSpacing: '.02em',
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? .55 : 1,
    transition:
      'background var(--dur-fast), color var(--dur-fast), ' +
      'border-color var(--dur-fast), transform var(--dur-fast), ' +
      'box-shadow var(--dur-fast)',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    border: 'none',
  };

  const variants = {
    primary: {
      ...base,
      padding: 'var(--pad-btn-primary)',
      background: 'var(--color-cyan)',
      color: 'var(--text-on-dark)',
      boxShadow: 'var(--shadow-cyan-rest)',
    },
    outline: {
      ...base,
      padding: 'var(--pad-btn-outline)',
      background: 'transparent',
      color: 'var(--text-on-dark)',
      border: '2px solid rgba(255,255,255,.35)',
    },
  };

  const props = {
    onClick: disabled ? undefined : onClick,
    style: { ...variants[variant], ...style },
    className: 'syn-btn syn-btn-' + variant,
    ...rest,
  };

  if (Tag === 'a') props.href = href;
  else if (Tag === 'button') props.type = type || 'button';

  return React.createElement(Tag, props, children);
}
