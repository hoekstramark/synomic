/**
 * IconTile — the 54×54 cyan-tinted square that holds an emoji icon at the
 * top of a feature card. Smaller 44×44 variant is the .contact-detail-icon.
 */
export function IconTile({ children, size = 'md', style, ...rest }) {
  const sizes = {
    sm: { w: 44, r: 'var(--radius-md)', fs: '1.1rem' },
    md: { w: 54, r: 'var(--radius-xl)', fs: '1.4rem' },
  };
  const s = sizes[size];
  const wrap = {
    width: s.w, height: s.w,
    borderRadius: s.r,
    background: 'var(--cyan-10)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: s.fs,
    flexShrink: 0,
    ...style,
  };
  return React.createElement('div', { className: 'syn-icontile', style: wrap, ...rest }, children);
}
