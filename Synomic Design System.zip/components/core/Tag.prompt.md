Small uppercase capsule for categorical labels. Cyan-tinted background by default.

```jsx
<Tag>Finance</Tag>
<Tag>Dienst 01</Tag>
<Tag tone="muted">Power BI</Tag>
```

Use `tone="muted"` for tech-stack chips at the bottom of project cards — they fade behind the title without competing.
