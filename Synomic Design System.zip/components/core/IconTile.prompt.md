The cyan-tinted square that holds a single emoji. Two sizes — `md` (54px, default, feature cards) and `sm` (44px, contact details).

```jsx
<IconTile>🎯</IconTile>
<IconTile size="sm">📍</IconTile>
```
