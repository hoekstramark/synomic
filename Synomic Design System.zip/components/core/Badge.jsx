/**
 * Badge — capsule with a pulsing dot.
 *
 * Used as the hero eyebrow ("Finance · IT · AI Automatisering") and the
 * "Klaar voor de volgende stap?" banner label.
 *
 * Lives on dark backdrops only. Reads cyan-on-cyan-tinted-translucent.
 */
export function Badge({ children, dot = true, style, ...rest }) {
  const wrap = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    background: 'var(--cyan-15)',
    border: '1px solid var(--cyan-35)',
    borderRadius: 'var(--radius-pill)',
    padding: 'var(--pad-pill)',
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--fz-1)',
    fontWeight: 600,
    color: 'var(--color-cyan)',
    letterSpacing: 'var(--ls-wider)',
    textTransform: 'uppercase',
    ...style,
  };
  const d = {
    width: 7,
    height: 7,
    borderRadius: '50%',
    background: 'var(--color-cyan)',
    animation: 'synomic-pulse-dot 2s infinite',
  };
  return React.createElement(
    'span',
    { className: 'syn-badge', style: wrap, ...rest },
    dot ? React.createElement('span', { style: d, 'aria-hidden': true }) : null,
    children
  );
}
