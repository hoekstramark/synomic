import * as React from 'react';

export interface SelectOption { value: string; label: string }

/** Native select wrapped in Synomic's field shell. Same focus ring & error states as TextField. */
export interface SelectProps {
  id?: string;
  name?: string;
  label?: React.ReactNode;
  required?: boolean;
  /** Options can be plain strings or `{value, label}` objects. */
  options: (string | SelectOption)[];
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  error?: string;
  style?: React.CSSProperties;
}

export function Select(props: SelectProps): JSX.Element;
