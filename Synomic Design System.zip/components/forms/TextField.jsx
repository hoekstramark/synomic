/**
 * TextField — Synomic's stock text input.
 *
 * Single component covers both `<input>` and `<textarea>` (set `multiline` to
 * render a textarea). The visual treatment is identical: 1.5px border that
 * highlights to cyan on focus with a soft cyan focus ring.
 *
 * `error` swaps the border for red + a red ring (validation state).
 *
 * Always renders inside a `<div class="syn-field">` wrapper that holds the
 * label, the field, and a `field-error` slot. The label uses a cyan asterisk
 * to mark "required" (matches the live site's `<span>*</span>`).
 */
export function TextField({
  id,
  name,
  label,
  required,
  optional,
  placeholder,
  type = 'text',
  multiline,
  rows = 5,
  value,
  defaultValue,
  onChange,
  error,
  helperText,
  maxLength,
  autoComplete,
  style,
  ...rest
}) {
  const wrapStyle = { marginBottom: 22, ...style };
  const labelStyle = {
    display: 'block',
    fontFamily: 'var(--font-body)',
    fontSize: '.88rem',
    fontWeight: 600,
    color: 'var(--text-strong)',
    marginBottom: 8,
  };
  const reqStyle = { color: 'var(--color-cyan)', marginLeft: 4 };
  const optStyle = { color: 'var(--text-muted)', fontWeight: 400, marginLeft: 6 };

  const fieldStyle = {
    width: '100%',
    padding: 'var(--pad-input)',
    border: '1.5px solid ' + (error ? 'var(--status-error)' : 'var(--border-default)'),
    borderRadius: 'var(--radius-md)',
    fontFamily: 'var(--font-body)',
    fontSize: '.95rem',
    color: 'var(--text-body)',
    background: 'var(--surface-card)',
    outline: 'none',
    transition: 'border-color var(--dur-fast), box-shadow var(--dur-fast)',
    boxShadow: error ? 'var(--ring-error)' : 'none',
    resize: multiline ? 'vertical' : undefined,
    minHeight: multiline ? 130 : undefined,
  };

  const helperRow = { display: 'flex', justifyContent: 'space-between', marginTop: 4, gap: 8 };
  const helperStyle = { fontFamily: 'var(--font-body)', fontSize: '.78rem', color: error ? 'var(--status-error)' : 'var(--text-muted)' };

  const FieldEl = multiline ? 'textarea' : 'input';
  const fieldProps = {
    id, name,
    placeholder, value, defaultValue, onChange,
    maxLength, autoComplete, required,
    style: fieldStyle,
    className: 'syn-field-control' + (error ? ' is-invalid' : ''),
    ...rest,
  };
  if (!multiline) fieldProps.type = type;
  else fieldProps.rows = rows;

  return React.createElement(
    'div',
    { className: 'syn-field', style: wrapStyle },
    label
      ? React.createElement(
          'label',
          { htmlFor: id, style: labelStyle },
          label,
          required ? React.createElement('span', { style: reqStyle }, '*') : null,
          optional ? React.createElement('span', { style: optStyle }, '(optioneel)') : null
        )
      : null,
    React.createElement(FieldEl, fieldProps),
    error || helperText
      ? React.createElement(
          'div',
          { style: helperRow },
          React.createElement('span', { style: helperStyle }, error || helperText)
        )
      : null
  );
}
