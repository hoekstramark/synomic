/**
 * Checkbox — Synomic uses native checkboxes with `accent-color: var(--color-cyan)`
 * and a long muted label beside them (the contact form privacy box pattern).
 */
export function Checkbox({ id, name, label, required, checked, defaultChecked, onChange, error, style, ...rest }) {
  const row = { display: 'flex', gap: 12, alignItems: 'flex-start', ...style };
  const box = {
    width: 18, height: 18, marginTop: 2,
    accentColor: 'var(--color-cyan)',
    cursor: 'pointer',
    flexShrink: 0,
  };
  const labelStyle = {
    fontFamily: 'var(--font-body)',
    fontSize: '.88rem',
    color: 'var(--text-muted)',
    cursor: 'pointer',
    lineHeight: 1.5,
  };
  const reqStyle = { color: 'var(--color-cyan)' };
  const helperStyle = { fontFamily: 'var(--font-body)', fontSize: '.78rem', color: 'var(--status-error)', marginTop: 5, marginLeft: 30 };

  return React.createElement(
    'div', { className: 'syn-checkbox-wrap' },
    React.createElement(
      'div', { className: 'syn-checkbox', style: row },
      React.createElement('input', { id, name, type: 'checkbox', checked, defaultChecked, onChange, required, style: box, ...rest }),
      React.createElement(
        'label', { htmlFor: id, style: labelStyle },
        label,
        required ? React.createElement('span', { style: reqStyle }, ' *') : null
      )
    ),
    error ? React.createElement('div', { style: helperStyle }, error) : null
  );
}
