import * as React from 'react';

/** Native checkbox with `accent-color: cyan` and a long muted-text label. */
export interface CheckboxProps {
  id?: string;
  name?: string;
  /** Text or rich React node beside the checkbox. */
  label?: React.ReactNode;
  required?: boolean;
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  style?: React.CSSProperties;
}

export function Checkbox(props: CheckboxProps): JSX.Element;
