Stock text input. Set `multiline` to render a textarea (Synomic's contact form has both shapes in one visual style).

```jsx
<TextField id="email" label="E-mailadres" required type="email" autoComplete="email" />
<TextField id="bericht" label="Bericht" required multiline placeholder="Beschrijf kort de vraag…" />
<TextField id="email" label="E-mailadres" error="Geldig e-mailadres invullen." />
```

Required fields get a cyan asterisk; pass `optional` to label "(optioneel)" instead.
