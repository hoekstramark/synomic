/**
 * Select — native <select> wrapped in Synomic's field shell. Shares the
 * focus / error treatment with TextField.
 */
export function Select({
  id, name, label, required, options = [], placeholder = 'Selecteer…',
  value, defaultValue, onChange, error, style, ...rest
}) {
  const wrapStyle = { marginBottom: 22, ...style };
  const labelStyle = {
    display: 'block', fontFamily: 'var(--font-body)', fontSize: '.88rem',
    fontWeight: 600, color: 'var(--text-strong)', marginBottom: 8,
  };
  const reqStyle = { color: 'var(--color-cyan)', marginLeft: 4 };
  const fieldStyle = {
    width: '100%',
    padding: 'var(--pad-input)',
    border: '1.5px solid ' + (error ? 'var(--status-error)' : 'var(--border-default)'),
    borderRadius: 'var(--radius-md)',
    fontFamily: 'var(--font-body)',
    fontSize: '.95rem',
    color: 'var(--text-body)',
    background: 'var(--surface-card)',
    outline: 'none',
    transition: 'border-color var(--dur-fast), box-shadow var(--dur-fast)',
    appearance: 'none',
    backgroundImage: 'linear-gradient(45deg, transparent 50%, var(--text-muted) 50%), linear-gradient(135deg, var(--text-muted) 50%, transparent 50%)',
    backgroundPosition: 'calc(100% - 18px) 50%, calc(100% - 13px) 50%',
    backgroundSize: '5px 5px, 5px 5px',
    backgroundRepeat: 'no-repeat',
    paddingRight: 36,
  };
  const helperStyle = { fontFamily: 'var(--font-body)', fontSize: '.78rem', color: 'var(--status-error)', marginTop: 5 };

  return React.createElement(
    'div', { className: 'syn-field', style: wrapStyle },
    label
      ? React.createElement('label', { htmlFor: id, style: labelStyle }, label, required ? React.createElement('span', { style: reqStyle }, '*') : null)
      : null,
    React.createElement(
      'select',
      { id, name, value, defaultValue, onChange, required, style: fieldStyle, ...rest },
      placeholder ? React.createElement('option', { value: '' }, placeholder) : null,
      options.map(o =>
        typeof o === 'string'
          ? React.createElement('option', { key: o, value: o }, o)
          : React.createElement('option', { key: o.value, value: o.value }, o.label)
      )
    ),
    error ? React.createElement('div', { style: helperStyle }, error) : null
  );
}
