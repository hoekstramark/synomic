Native checkbox styled with Synomic cyan. Used inline with longer policy text.

```jsx
<Checkbox
  id="privacy" required
  label={<>Ik ga akkoord met het verwerken van mijn gegevens. Synomic deelt deze nooit met derden.</>}
/>
```
