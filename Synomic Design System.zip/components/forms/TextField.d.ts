import * as React from 'react';

/** Single text input or textarea. Cyan focus ring; red border on error. */
export interface TextFieldProps {
  id?: string;
  name?: string;
  label?: React.ReactNode;
  required?: boolean;
  optional?: boolean;
  placeholder?: string;
  type?: 'text' | 'email' | 'tel' | 'url' | 'number' | 'password';
  /** Render as `<textarea>` instead of `<input>`. */
  multiline?: boolean;
  rows?: number;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  /** Error message — shows in red + adds error ring. */
  error?: string;
  helperText?: string;
  maxLength?: number;
  autoComplete?: string;
  style?: React.CSSProperties;
}

export function TextField(props: TextFieldProps): JSX.Element;
