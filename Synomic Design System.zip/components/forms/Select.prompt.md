Native `<select>` in Synomic's field wrapper.

```jsx
<Select
  id="onderwerp" label="Onderwerp" required
  options={[
    { value: 'finance', label: 'Finance & Data-analyse' },
    { value: 'it',      label: 'IT & Automatisering' },
    { value: 'ai',      label: 'AI Toepassingen' },
  ]}
/>
```
