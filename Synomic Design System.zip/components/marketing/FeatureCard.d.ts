import * as React from 'react';

/**
 * Card opening with a cyan IconTile + H3 + muted body. The "Wie zijn wij" and
 * "Kernwaarden" tiles are both this shape.
 */
export interface FeatureCardProps {
  /** Emoji or small JSX rendered inside a 54×54 cyan tile. */
  icon?: React.ReactNode;
  title?: React.ReactNode;
  children?: React.ReactNode;
  href?: string;
  interactive?: boolean;
  style?: React.CSSProperties;
}

export function FeatureCard(props: FeatureCardProps): JSX.Element;
