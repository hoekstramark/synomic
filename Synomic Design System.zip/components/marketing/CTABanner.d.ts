import * as React from 'react';

export interface CTAButton { href: string; label: React.ReactNode }

/**
 * Closing CTA — navy-gradient block with eyebrow, headline and a primary button.
 */
export interface CTABannerProps {
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  cta?: CTAButton | null;
  style?: React.CSSProperties;
}

export function CTABanner(props: CTABannerProps): JSX.Element;
