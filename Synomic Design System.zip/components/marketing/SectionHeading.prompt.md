Synomic's stock section opener — small cyan eyebrow → bold Syne H2 → muted lede.

```jsx
<SectionHeading
  label="Specialisaties"
  title="Core Competencies"
  sub="Iedere opdracht is uniek. De aanpak wordt afgestemd op de specifieke uitdaging."
  align="center"
/>
```

Pass `tone="dark"` when the surrounding section is navy.
