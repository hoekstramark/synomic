Case-study tile. The same shape as every card on the Projecten page.

```jsx
<ProjectCard
  icon="📊"
  category="Finance"
  title="Financieel dashboard MKB"
  stack={['Power BI', 'Excel', 'API-koppeling']}
>
  Real-time Power BI dashboard gekoppeld aan boekhoudpakket. Management heeft nu altijd up-to-date inzicht in kasstromen, marges en KPI's.
</ProjectCard>
```
