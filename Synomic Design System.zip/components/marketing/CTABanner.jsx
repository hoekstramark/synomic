/**
 * CTABanner — the dark navy-gradient banner that closes most pages.
 *
 * Headline + primary cyan button sit on a 56px-padded navy gradient block
 * with a corner cyan radial glow.
 */
export function CTABanner({ eyebrow, title, cta = { href: 'contact.html', label: 'Start een gesprek →' }, style }) {
  const Button = window.SynomicDesignSystem_d4bf5f.Button;

  const wrap = {
    background: 'linear-gradient(135deg, var(--color-navy) 0%, var(--color-navy-mid) 100%)',
    borderRadius: 'var(--radius-3xl)',
    padding: '56px 48px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 32,
    flexWrap: 'wrap',
    position: 'relative',
    overflow: 'hidden',
    ...style,
  };
  const orb = {
    position: 'absolute', right: -30, top: -30, width: 200, height: 200,
    borderRadius: '50%',
    background: 'radial-gradient(circle, var(--cyan-18) 0%, transparent 70%)',
    pointerEvents: 'none',
  };
  const eyeStyle = {
    color: 'var(--text-on-dark-low)',
    fontSize: 'var(--fz-3)',
    fontWeight: 700,
    letterSpacing: 'var(--ls-widest)',
    textTransform: 'uppercase',
    marginBottom: 8,
    fontFamily: 'var(--font-body)',
  };
  const titleStyle = {
    color: 'var(--text-on-dark)',
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 'clamp(1.5rem, 3vw, 2.2rem)',
    lineHeight: 'var(--lh-display)',
    margin: 0,
  };

  return React.createElement(
    'div', { className: 'syn-cta-banner', style: wrap },
    React.createElement('div', { style: orb, 'aria-hidden': true }),
    React.createElement(
      'div', { style: { position: 'relative', zIndex: 2 } },
      eyebrow ? React.createElement('p', { style: eyeStyle }, eyebrow) : null,
      title ? React.createElement('h2', { style: titleStyle }, title) : null
    ),
    cta
      ? React.createElement(Button, { href: cta.href, style: { flexShrink: 0, position: 'relative', zIndex: 2 } }, cta.label)
      : null
  );
}
