The dark-navy gradient block that closes every Synomic page.

```jsx
<CTABanner
  eyebrow="Klaar voor de volgende stap?"
  title="Samen bouwen aan een digitale toekomst"
  cta={{ href: 'contact.html', label: 'Start een gesprek →' }}
/>
```
