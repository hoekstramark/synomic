The homepage hero block — navy gradient, dot-grid texture, cyan corner glows, badge + headline + CTAs.

```jsx
<Hero
  badge="Finance · IT · AI Automatisering"
  title="Slimme oplossingen voor"
  cyanWord="digitale groei"
  intro="Technologie die werkt voor mensen, niet andersom. Synomic automatiseert, verbindt en optimaliseert."
  primary={{ href: 'diensten.html', label: 'Bekijk diensten' }}
  secondary={{ href: 'contact.html', label: 'Neem contact op' }}
  stats={[
    { n: '30', accent: '+', label: 'Projecten' },
    { n: '4', label: 'Specialisaties' },
  ]}
/>
```
