import * as React from 'react';

/** Horizontal partner card: 44×44 logo swatch + name + role. Used in the tools strip. */
export interface PartnerPillProps {
  /** Image src OR a React node. */
  logo?: React.ReactNode;
  logoAlt?: string;
  name: React.ReactNode;
  role?: React.ReactNode;
  href?: string;
  style?: React.CSSProperties;
}

export function PartnerPill(props: PartnerPillProps): JSX.Element;
