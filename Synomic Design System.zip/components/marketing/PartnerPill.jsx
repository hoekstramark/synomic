/**
 * PartnerPill — a horizontal anchor card with a 44×44 logo swatch on the left
 * and partner name + role on the right. Used in the "Technologieën & tools"
 * strip.
 */
export function PartnerPill({ logo, logoAlt, name, role, href, style }) {
  const wrap = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    background: 'var(--surface-card)',
    border: '1px solid var(--border-soft)',
    borderRadius: 'var(--radius-xl)',
    padding: '14px 20px',
    flex: 1,
    minWidth: 180,
    maxWidth: 280,
    textDecoration: 'none',
    transition: 'transform var(--dur-fast), box-shadow var(--dur-fast)',
    ...style,
  };
  const swatch = {
    width: 44, height: 44, minWidth: 44,
    borderRadius: 'var(--radius-md)',
    background: '#fff',
    border: '1px solid var(--border-soft)',
    overflow: 'hidden',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  };
  const nameStyle = { fontWeight: 700, fontSize: 'var(--fz-5)', color: 'var(--text-strong)', fontFamily: 'var(--font-display)' };
  const roleStyle = { fontSize: 'var(--fz-1)', color: 'var(--text-muted)', fontFamily: 'var(--font-body)' };

  const inner = React.createElement(
    React.Fragment, null,
    React.createElement(
      'div', { style: swatch },
      typeof logo === 'string'
        ? React.createElement('img', { src: logo, alt: logoAlt || name, style: { width: 32, height: 32, objectFit: 'contain' } })
        : logo
    ),
    React.createElement(
      'div', null,
      React.createElement('div', { style: nameStyle }, name),
      role ? React.createElement('div', { style: roleStyle }, role) : null
    )
  );

  return href
    ? React.createElement('a', { href, style: wrap, className: 'syn-partner-pill' }, inner)
    : React.createElement('div', { style: wrap, className: 'syn-partner-pill' }, inner);
}
