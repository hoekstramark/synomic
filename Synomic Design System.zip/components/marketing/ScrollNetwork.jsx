/**
 * ScrollNetwork — scroll-driven SVG network illustration.
 *
 * The network shows Synomic's working method visually: three pillars
 * (Finance · IT · AI) feed into a central Synomic hub, which in turn
 * produces three customer outcomes (Meetbare impact · Schaalbare groei ·
 * Slimmere processen).
 *
 * Visual treatment matches the brand on white: white surface, hairline
 * border, subtle cyan dot-grid + glow orbs. Cyan nodes, navy hub, navy
 * labels. No dark panel — the widget sits on the surrounding white section
 * as a normal Synomic card would.
 *
 * Motion:
 *   • All nodes are visible from progress 0 (faint at first).
 *   • Top nodes light up + edges to the hub draw in within the first 25%
 *     of scroll progress.
 *   • The hub then lights with a continuous pulsing halo.
 *   • Hub-to-outcome edges flow downward; outcome nodes slide UP into
 *     position from below as they activate (the "naar beneden" motion).
 *   • Once an edge is drawn, a small cyan spark continuously travels along
 *     it — keeps the diagram alive without the user needing to keep scrolling.
 *   • Animation completes by ~55% scroll progress — designed to feel compact.
 *
 * Interactions:
 *   • Hovering any node highlights it and the edges that touch it.
 *   • Bottom progress bar mirrors scroll position with a cyan gradient.
 *
 * Scroll-anchor resolution:
 *   Walks up the DOM looking for an ancestor with `data-scroll-anchor="1"`.
 *   Falls back to immediate parent. Set the anchor on the surrounding
 *   section so scroll progress is measured against the right element when
 *   the network sits inside a `position: sticky` wrapper.
 */
const SN_NODES = [
  { id: 'finance', x: 90,  y: 92,  r: 19, label: ['Finance'],                lit: 0.00 },
  { id: 'it',      x: 240, y: 74,  r: 19, label: ['IT'],                     lit: 0.03 },
  { id: 'ai',      x: 390, y: 92,  r: 19, label: ['AI'],                     lit: 0.06 },
  { id: 'hub',     x: 240, y: 295, r: 32, label: ['Synomic'],                lit: 0.18, central: true },
  { id: 'impact',  x: 90,  y: 478, r: 17, label: ['Meetbare','impact'],      lit: 0.36, slideIn: true },
  { id: 'groei',   x: 240, y: 496, r: 17, label: ['Schaalbare','groei'],     lit: 0.42, slideIn: true },
  { id: 'proces',  x: 390, y: 478, r: 17, label: ['Slimmere','processen'],   lit: 0.48, slideIn: true },
];
const SN_EDGES = [
  { from: 'finance', to: 'hub',    s: 0.04, e: 0.18 },
  { from: 'it',      to: 'hub',    s: 0.07, e: 0.20 },
  { from: 'ai',      to: 'hub',    s: 0.10, e: 0.22 },
  { from: 'hub',     to: 'impact', s: 0.26, e: 0.40 },
  { from: 'hub',     to: 'groei',  s: 0.30, e: 0.44 },
  { from: 'hub',     to: 'proces', s: 0.34, e: 0.48 },
];

function _snClamp(v) { return Math.max(0, Math.min(1, v)); }
function _snSmooth(v) { v = _snClamp(v); return v * v * (3 - 2 * v); }
function _snEdgePath(a, b) {
  const mx = (a.x + b.x) / 2;
  const my = (a.y + b.y) / 2;
  const off = (b.x - a.x) * 0.07;
  return 'M ' + a.x + ' ' + a.y + ' Q ' + (mx + off) + ' ' + my + ' ' + b.x + ' ' + b.y;
}

export function ScrollNetwork({ height = 600, style }) {
  const h = React.createElement;
  const wrapRef = React.useRef(null);
  const [progress, setProgress] = React.useState(0);
  const [hover, setHover] = React.useState(null);

  React.useEffect(() => {
    if (!wrapRef.current) return;
    let anchor = wrapRef.current.parentElement;
    let walk = anchor;
    while (walk) {
      if (walk.getAttribute && walk.getAttribute('data-scroll-anchor') === '1') {
        anchor = walk;
        break;
      }
      walk = walk.parentElement;
    }
    let raf = null;
    const update = () => {
      raf = null;
      if (!anchor) return;
      const rect = anchor.getBoundingClientRect();
      const vh = window.innerHeight || 800;
      const startY = vh * 0.85;
      const endY = vh * 0.15;
      const total = rect.height + (startY - endY);
      const elapsed = startY - rect.top;
      setProgress(_snClamp(elapsed / total));
    };
    const onScroll = () => { if (raf == null) raf = requestAnimationFrame(update); };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', update);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', update);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const byId = {};
  SN_NODES.forEach(n => { byId[n.id] = n; });

  // Floor opacity 0.22 so the layout is immediately legible; brightens to 1.0.
  const nodeP = (n) => {
    const t = _snSmooth((progress - n.lit) / 0.10);
    return 0.22 + 0.78 * t;
  };
  // Bottom nodes slide UP from below — the "naar beneden" flow from Synomic.
  const slideY = (n) => {
    if (!n.slideIn) return 0;
    const t = _snSmooth((progress - n.lit + 0.04) / 0.10);
    return (1 - t) * 32;
  };
  const edgeP = (e) => _snSmooth((progress - e.s) / (e.e - e.s));

  // ---- background panel — light, sits on white sections ----
  const bg = h('div', {
    style: {
      position: 'absolute', inset: 0,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-3xl)',
      overflow: 'hidden',
    },
  },
    h('div', { style: {
      position: 'absolute', inset: 0,
      backgroundImage: 'radial-gradient(circle, rgba(43,196,196,.16) 1px, transparent 1px)',
      backgroundSize: '22px 22px',
      opacity: 0.5,
    }}),
    h('div', { style: {
      position: 'absolute', top: -60, right: -60,
      width: 260, height: 260, borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(43,196,196,.18) 0%, transparent 70%)',
      pointerEvents: 'none',
    }}),
    h('div', { style: {
      position: 'absolute', bottom: -70, left: -50,
      width: 240, height: 240, borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(43,196,196,.12) 0%, transparent 70%)',
      pointerEvents: 'none',
    }})
  );

  // ---- defs (gradients, glow, animations) ----
  const defs = h('defs', null,
    h('radialGradient', { id: 'sn-node-grad', cx: '50%', cy: '38%', r: '60%' },
      h('stop', { offset: '0%',  stopColor: '#A8F0F0', stopOpacity: '1' }),
      h('stop', { offset: '55%', stopColor: '#2BC4C4', stopOpacity: '1' }),
      h('stop', { offset: '100%', stopColor: '#1A9E9E', stopOpacity: '1' })
    ),
    h('radialGradient', { id: 'sn-hub-grad', cx: '50%', cy: '38%', r: '65%' },
      h('stop', { offset: '0%',  stopColor: '#1A4D6E', stopOpacity: '1' }),
      h('stop', { offset: '60%', stopColor: '#1B3A5C', stopOpacity: '1' }),
      h('stop', { offset: '100%', stopColor: '#0E2136', stopOpacity: '1' })
    ),
    h('filter', { id: 'sn-glow', x: '-50%', y: '-50%', width: '200%', height: '200%' },
      h('feGaussianBlur', { stdDeviation: '2.4', result: 'blur' }),
      h('feMerge', null,
        h('feMergeNode', { in: 'blur' }),
        h('feMergeNode', { in: 'SourceGraphic' })
      )
    ),
    h('filter', { id: 'sn-glow-strong', x: '-50%', y: '-50%', width: '200%', height: '200%' },
      h('feGaussianBlur', { stdDeviation: '4', result: 'blur' }),
      h('feMerge', null,
        h('feMergeNode', { in: 'blur' }),
        h('feMergeNode', { in: 'SourceGraphic' })
      )
    )
  );

  // ---- orbit rings around the hub ----
  const orbits = h('g', { opacity: 0.7 },
    h('animateTransform', {
      attributeName: 'transform', type: 'rotate',
      from: '0 240 295', to: '360 240 295',
      dur: '60s', repeatCount: 'indefinite',
    }),
    h('circle', { cx: 240, cy: 295, r: 64,
      fill: 'none', stroke: 'rgba(43,196,196,.45)', strokeWidth: 1, strokeDasharray: '2 6' }),
    h('circle', { cx: 240, cy: 295, r: 92,
      fill: 'none', stroke: 'rgba(43,196,196,.22)', strokeWidth: 1, strokeDasharray: '3 11' })
  );
  const orbitInner = h('g', { opacity: 0.6 },
    h('animateTransform', {
      attributeName: 'transform', type: 'rotate',
      from: '360 240 295', to: '0 240 295',
      dur: '40s', repeatCount: 'indefinite',
    }),
    h('circle', { cx: 240, cy: 295, r: 46,
      fill: 'none', stroke: 'rgba(43,196,196,.18)', strokeWidth: 1, strokeDasharray: '1 7' })
  );

  // ---- edges ----
  const edgeEls = SN_EDGES.map((e, i) => {
    const a = byId[e.from];
    const b = byId[e.to];
    // Bottom edges always render to the node's CURRENT (post-slide) position
    // so the connection feels physical, not "drawn in mid-air".
    const bX = b.x;
    const bY = b.y + slideY(b);
    const path = _snEdgePath({ x: a.x, y: a.y }, { x: bX, y: bY });
    const len = Math.hypot(bX - a.x, bY - a.y) * 1.06;
    const p = edgeP(e);
    const hot = hover && (hover === e.from || hover === e.to);
    const fullyDrawn = p > 0.97;
    return h('g', { key: 'e' + i },
      // soft glow underlay
      h('path', { d: path, fill: 'none',
        stroke: hot ? 'rgba(43,196,196,.55)' : 'rgba(43,196,196,.32)',
        strokeWidth: 7, strokeLinecap: 'round',
        style: { filter: 'blur(4px)', opacity: p * 0.7, transition: 'stroke .25s' },
      }),
      // base "ghost" line — faint visible suggestion even before drawn
      h('path', { d: path, fill: 'none',
        stroke: 'rgba(27,58,92,.08)',
        strokeWidth: 1, strokeLinecap: 'round',
        strokeDasharray: '2 5',
      }),
      // sharp drawn line
      h('path', { d: path, fill: 'none',
        stroke: hot ? '#1A9E9E' : '#2BC4C4',
        strokeWidth: hot ? 2.2 : 1.6,
        strokeLinecap: 'round',
        strokeDasharray: len,
        strokeDashoffset: (1 - p) * len,
        style: { transition: 'stroke .25s, stroke-width .25s' },
      }),
      // traveling spark — only once edge is essentially drawn
      fullyDrawn ? h('circle', { key: 's' + i, r: 2.5, fill: '#2BC4C4', filter: 'url(#sn-glow-strong)' },
        h('animateMotion', { dur: '3.0s', repeatCount: 'indefinite', path: path, begin: (i * 0.5) + 's' }),
        h('animate', { attributeName: 'opacity', values: '0;1;1;0', keyTimes: '0;0.15;0.85;1', dur: '3.0s', repeatCount: 'indefinite', begin: (i * 0.5) + 's' })
      ) : null
    );
  });

  // ---- nodes ----
  const nodeEls = SN_NODES.map((n) => {
    const op = nodeP(n);
    const dy = slideY(n);
    const hot = hover === n.id;
    const inner = [];
    if (n.central) {
      // pulsing cyan halo behind the navy hub
      inner.push(h('circle', { key: 'h1', cx: n.x, cy: n.y, r: n.r + 14, fill: 'rgba(43,196,196,.22)' },
        h('animate', { attributeName: 'r', values: (n.r + 10) + ';' + (n.r + 22) + ';' + (n.r + 10), dur: '2.8s', repeatCount: 'indefinite' }),
        h('animate', { attributeName: 'opacity', values: '.45;.12;.45', dur: '2.8s', repeatCount: 'indefinite' })
      ));
      // cyan ring around the hub
      inner.push(h('circle', { key: 'h2', cx: n.x, cy: n.y, r: n.r + 4, fill: 'none',
        stroke: '#2BC4C4', strokeWidth: 1.5, opacity: 0.6 }));
      // navy core
      inner.push(h('circle', { key: 'h3', cx: n.x, cy: n.y, r: n.r, fill: 'url(#sn-hub-grad)', filter: 'url(#sn-glow)' }));
      // central cyan dot
      inner.push(h('circle', { key: 'h4', cx: n.x, cy: n.y, r: n.r * 0.22, fill: '#2BC4C4' }));
    } else {
      // soft halo
      inner.push(h('circle', { key: 'a', cx: n.x, cy: n.y, r: n.r + 4, fill: 'rgba(43,196,196,.22)' },
        h('animate', { attributeName: 'r', values: (n.r + 2) + ';' + (n.r + 7) + ';' + (n.r + 2), dur: '3.4s', repeatCount: 'indefinite' }),
        h('animate', { attributeName: 'opacity', values: '.35;.1;.35', dur: '3.4s', repeatCount: 'indefinite' })
      ));
      // cyan node
      inner.push(h('circle', { key: 'b', cx: n.x, cy: n.y, r: n.r, fill: 'url(#sn-node-grad)', filter: 'url(#sn-glow)' }));
      // inner highlight
      inner.push(h('circle', { key: 'c', cx: n.x, cy: n.y - n.r * 0.2, r: n.r * 0.32, fill: '#ffffff', opacity: 0.55 }));
    }
    // label — multi-line via tspans, navy text on light surface
    const labelLines = n.label;
    const labelEl = h('text', {
      key: 't',
      x: n.x,
      y: n.y + n.r + 22,
      textAnchor: 'middle',
      fill: hot ? '#1A9E9E' : '#1B3A5C',
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 10.5,
        letterSpacing: '.12em',
        textTransform: 'uppercase',
        transition: 'fill .2s',
        pointerEvents: 'none',
      },
    }, ...labelLines.map((line, idx) =>
      h('tspan', { key: idx, x: n.x, dy: idx === 0 ? 0 : '1.25em' }, line)
    ));
    inner.push(labelEl);

    return h('g', {
      key: n.id,
      onMouseEnter: () => setHover(n.id),
      onMouseLeave: () => setHover(null),
      style: {
        opacity: op,
        transform: 'translateY(' + dy + 'px)' + (hot ? ' scale(1.10)' : ''),
        transformOrigin: n.x + 'px ' + n.y + 'px',
        transition: 'transform .25s, opacity .35s',
        cursor: 'pointer',
      },
    }, ...inner);
  });

  // ---- ambient floating particles ----
  const ambient = h('g', { opacity: 0.45 },
    [{x:35,y:180},{x:445,y:220},{x:50,y:360},{x:430,y:360},{x:30,y:250},{x:455,y:130}].map((d, i) => (
      h('circle', { key: 'p' + i, cx: d.x, cy: d.y, r: 1.6, fill: '#2BC4C4' },
        h('animate', {
          attributeName: 'cy',
          values: (d.y - 10) + ';' + (d.y + 10) + ';' + (d.y - 10),
          dur: (5 + (i % 4)) + 's', repeatCount: 'indefinite',
        }),
        h('animate', {
          attributeName: 'opacity',
          values: '.2;.8;.2',
          dur: (4 + (i % 3)) + 's', repeatCount: 'indefinite',
        })
      )
    ))
  );

  const svg = h('svg', {
    viewBox: '0 0 480 620',
    preserveAspectRatio: 'xMidYMid meet',
    style: { position: 'relative', width: '100%', height: '100%', display: 'block', overflow: 'visible' },
  }, defs, ambient, orbits, orbitInner, ...edgeEls, ...nodeEls);

  // ---- caption (top) ----
  const caption = h('div', {
    style: {
      position: 'absolute', top: 22, left: 24, right: 24,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      fontFamily: 'var(--font-body)', fontSize: 10, fontWeight: 700,
      letterSpacing: '.18em', textTransform: 'uppercase',
      color: 'var(--text-muted)',
      pointerEvents: 'none',
    },
  },
    h('span', null, 'Werkwijze · live'),
    h('span', { style: { color: 'var(--color-cyan)' } }, Math.round(progress * 100) + '%')
  );

  // ---- bottom progress bar ----
  const progressBar = h('div', {
    style: {
      position: 'absolute', bottom: 20, left: 24, right: 24,
      height: 2, background: 'rgba(27,58,92,.10)', borderRadius: 999, overflow: 'hidden',
    },
  },
    h('div', { style: {
      height: '100%', width: (progress * 100) + '%',
      background: 'linear-gradient(90deg, transparent, #2BC4C4 30%, #1A9E9E)',
      boxShadow: '0 0 8px rgba(43,196,196,.4)',
      transition: 'width .12s linear',
    }})
  );

  return h('div', {
    ref: wrapRef,
    className: 'syn-scroll-network',
    style: { position: 'relative', width: '100%', height, ...style },
  }, bg, svg, caption, progressBar);
}
