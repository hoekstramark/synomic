/**
 * FeatureCard — a card that opens with a 54×54 cyan-tinted IconTile, then an
 * H3 title and a muted paragraph. The home-page "Wie zijn wij" tiles and the
 * "Kernwaarden" tiles are both this.
 *
 * Defaults to the `Card` interactive treatment — hover lift + gradient
 * top-border accent. Set `interactive={false}` if it sits inside a static
 * grid you don't want to animate.
 */
export function FeatureCard({ icon, title, children, href, interactive = true, style }) {
  const Card = window.SynomicDesignSystem_d4bf5f.Card;
  const IconTile = window.SynomicDesignSystem_d4bf5f.IconTile;

  const titleStyle = {
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 'var(--fz-h4)',
    color: 'var(--text-strong)',
    marginBottom: 10,
    marginTop: 20,
  };
  const bodyStyle = {
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--fz-5)',
    color: 'var(--text-muted)',
    lineHeight: 'var(--lh-body-tight)',
  };

  const inner = React.createElement(
    React.Fragment, null,
    icon ? React.createElement(IconTile, null, icon) : null,
    title ? React.createElement('h3', { style: titleStyle }, title) : null,
    children ? React.createElement('p', { style: bodyStyle }, children) : null
  );

  if (href) {
    return React.createElement(
      Card,
      { interactive, style: { display: 'block', textDecoration: 'none', color: 'inherit', ...style }, as: 'a' },
      React.createElement('a', { href, style: { textDecoration: 'none', color: 'inherit', display: 'block' } }, inner)
    );
  }
  return React.createElement(Card, { interactive, style }, inner);
}
