Scroll-driven interactive network illustration. Navy gradient panel, cyan nodes connected by curved edges that draw themselves as the user scrolls. Continuous data-flow sparks travel along finished edges; hovering a node lights it and its connections.

```jsx
<section data-scroll-anchor="1" style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 60 }}>
  <div>{/* scrolling text + cards */}</div>
  <div>
    <div style={{ position: 'sticky', top: 100 }}>
      <ScrollNetwork height={560} />
    </div>
  </div>
</section>
```

The component walks up the DOM looking for the nearest `data-scroll-anchor="1"` and ties progress to that element's scroll position. Without one, it uses its immediate parent.
