import * as React from 'react';

/**
 * Scroll-driven SVG network illustration in Synomic's navy/cyan palette.
 *
 * Place inside a `position: sticky` wrapper next to scrolling text content.
 * Set `data-scroll-anchor="1"` on the parent section to control which element
 * drives the animation (defaults to the immediate DOM parent).
 */
export interface ScrollNetworkProps {
  /** Total SVG height in px. Default 560. */
  height?: number;
  style?: React.CSSProperties;
}

export function ScrollNetwork(props: ScrollNetworkProps): JSX.Element;
