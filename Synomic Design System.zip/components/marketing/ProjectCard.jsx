/**
 * ProjectCard — case-study tile from the Projecten page.
 *
 * Top: 160-tall navy gradient block with a single large emoji icon.
 * Then: category tag, H3, body paragraph, and an inline tech-stack row
 * separated by · dots, all rendered with muted typography.
 */
export function ProjectCard({ icon, category, title, children, stack = [], style }) {
  const Card = window.SynomicDesignSystem_d4bf5f.Card;
  const Tag = window.SynomicDesignSystem_d4bf5f.Tag;

  const tile = {
    background: 'var(--gradient-header)',
    borderRadius: 'var(--radius-md)',
    height: 160,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '3rem',
    marginBottom: 20,
  };
  const titleStyle = { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--fz-h4)', marginBottom: 10, marginTop: 0, color: 'var(--text-strong)' };
  const bodyStyle  = { fontFamily: 'var(--font-body)', fontSize: 'var(--fz-5)', color: 'var(--text-muted)', lineHeight: 'var(--lh-body-tight)' };
  const stackRow = {
    marginTop: 20, paddingTop: 16,
    borderTop: '1px solid var(--border-default)',
    display: 'flex', gap: 8, flexWrap: 'wrap',
    fontFamily: 'var(--font-body)', fontSize: '.78rem', color: 'var(--text-muted)',
    alignItems: 'center',
  };

  const stackBits = [];
  stack.forEach((s, i) => {
    if (i > 0) stackBits.push(React.createElement('span', { key: 'd' + i, style: { color: 'var(--border-default)' } }, '·'));
    stackBits.push(React.createElement('span', { key: 's' + i }, s));
  });

  return React.createElement(
    Card, { style },
    React.createElement('div', { style: tile, 'aria-hidden': true }, icon),
    category ? React.createElement(Tag, { style: { marginBottom: 12, display: 'inline-block' } }, category) : null,
    title ? React.createElement('h3', { style: titleStyle }, title) : null,
    children ? React.createElement('p', { style: bodyStyle }, children) : null,
    stack.length ? React.createElement('div', { style: stackRow }, ...stackBits) : null
  );
}
