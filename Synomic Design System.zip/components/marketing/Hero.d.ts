import * as React from 'react';

export interface HeroCTA { href: string; label: React.ReactNode }
export interface HeroStat { n: React.ReactNode; accent?: React.ReactNode; label: React.ReactNode }

/**
 * Homepage hero. Navy gradient + dot grid + radial cyan glows behind a
 * badge → H1 → lede → CTA pair → optional stats strip column.
 */
export interface HeroProps {
  badge?: React.ReactNode;
  title?: React.ReactNode;
  /** Highlight word/phrase styled in cyan (e.g. "digitale groei"). */
  cyanWord?: React.ReactNode;
  intro?: React.ReactNode;
  primary?: HeroCTA;
  secondary?: HeroCTA;
  /** Optional stats strip below the CTAs. */
  stats?: HeroStat[];
  style?: React.CSSProperties;
}

export function Hero(props: HeroProps): JSX.Element;
