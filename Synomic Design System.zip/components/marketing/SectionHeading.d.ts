import * as React from 'react';

/** Stock section opener: small cyan eyebrow label + H2 + muted lede. */
export interface SectionHeadingProps {
  /** Tiny uppercase cyan label above the title. */
  label?: React.ReactNode;
  title?: React.ReactNode;
  sub?: React.ReactNode;
  align?: 'start' | 'center';
  /** Use `dark` when placed on a navy section. */
  tone?: 'light' | 'dark';
  maxSubWidth?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export function SectionHeading(props: SectionHeadingProps): JSX.Element;
