/**
 * Hero — the homepage hero. Navy gradient, dot grid, badge → big H1 → lede →
 * two CTAs → optional below-the-fold stats strip.
 *
 * The H1 accepts a `cyanWord` for the cyan-tinted highlight word (matches the
 * live site's `<em>digitale groei</em>` pattern).
 */
export function Hero({ badge, title, cyanWord, intro, primary, secondary, stats, style }) {
  const Badge = window.SynomicDesignSystem_d4bf5f.Badge;
  const Button = window.SynomicDesignSystem_d4bf5f.Button;
  const Stat = window.SynomicDesignSystem_d4bf5f.Stat;

  const wrap = {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    padding: '100px var(--page-pad-x) 60px',
    background: 'var(--gradient-hero)',
    position: 'relative',
    overflow: 'hidden',
    ...style,
  };
  const dots = {
    position: 'absolute', inset: 0,
    backgroundImage: 'var(--gradient-dotgrid-cyan)',
    backgroundSize: '48px 48px',
    pointerEvents: 'none',
  };
  const orbA = {
    position: 'absolute', top: -60, right: -60,
    width: 520, height: 520, borderRadius: '50%',
    background: 'radial-gradient(circle, var(--cyan-18) 0%, transparent 70%)',
    pointerEvents: 'none',
  };
  const orbB = {
    position: 'absolute', bottom: -80, left: '10%',
    width: 360, height: 360, borderRadius: '50%',
    background: 'radial-gradient(circle, var(--cyan-10) 0%, transparent 70%)',
    pointerEvents: 'none',
  };
  const content = { maxWidth: 640, position: 'relative', zIndex: 2 };
  const h1 = {
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 'var(--fz-hero)',
    color: 'var(--text-on-dark)',
    marginTop: 28,
    marginBottom: 24,
    lineHeight: 'var(--lh-display)',
  };
  const accent = { color: 'var(--color-cyan)', fontStyle: 'normal' };
  const p = {
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--fz-8)',
    color: 'var(--text-on-dark-mid)',
    maxWidth: 520,
    marginBottom: 40,
  };
  const buttonRow = { display: 'flex', gap: 16, flexWrap: 'wrap' };
  const statsRow = {
    display: 'flex', gap: 48,
    marginTop: 64, paddingTop: 40,
    borderTop: 'var(--border-on-dark) 1px solid',
  };

  return React.createElement(
    'section', { className: 'syn-hero', style: wrap },
    React.createElement('div', { style: dots, 'aria-hidden': true }),
    React.createElement('div', { style: orbA, 'aria-hidden': true }),
    React.createElement('div', { style: orbB, 'aria-hidden': true }),
    React.createElement(
      'div', { style: content },
      badge ? React.createElement(Badge, null, badge) : null,
      title ? React.createElement(
        'h1', { style: h1 },
        title,
        cyanWord ? React.createElement(React.Fragment, null, ' ', React.createElement('em', { style: accent }, cyanWord)) : null
      ) : null,
      intro ? React.createElement('p', { style: p }, intro) : null,
      (primary || secondary) ? React.createElement(
        'div', { style: buttonRow },
        primary ? React.createElement(Button, { href: primary.href }, primary.label) : null,
        secondary ? React.createElement(Button, { variant: 'outline', href: secondary.href }, secondary.label) : null
      ) : null,
      (stats && stats.length) ? React.createElement(
        'div', { style: statsRow },
        ...stats.map((s, i) => React.createElement(Stat, { key: i, n: s.n, accent: s.accent, label: s.label, size: 'sm' }))
      ) : null
    )
  );
}
