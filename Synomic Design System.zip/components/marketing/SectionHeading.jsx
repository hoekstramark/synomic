/**
 * SectionHeading — Synomic's stock section opener.
 *
 * Renders three vertical pieces:
 *   1. .section-label  — small uppercase cyan label
 *   2. .section-title  — H2 (Syne, bold, navy)
 *   3. .section-sub    — supporting paragraph (muted)
 *
 * Pass `align="center"` to center all three (used on "Kernwaarden" /
 * "Specialisaties" / CTA blocks). Default is left-aligned.
 *
 * On a navy section, set `tone="dark"` to flip text colors.
 */
export function SectionHeading({
  label,
  title,
  sub,
  align = 'start',
  tone = 'light',
  maxSubWidth = 540,
  style,
  children,
}) {
  const wrap = {
    textAlign: align === 'center' ? 'center' : 'left',
    marginBottom: sub ? 48 : 24,
    ...style,
  };
  const labelStyle = {
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--fz-1)',
    fontWeight: 700,
    letterSpacing: 'var(--ls-uppercase)',
    textTransform: 'uppercase',
    color: 'var(--color-cyan)',
    marginBottom: 12,
  };
  const titleStyle = {
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 'var(--fz-h2)',
    color: tone === 'dark' ? 'var(--text-on-dark)' : 'var(--text-strong)',
    marginBottom: 16,
    lineHeight: 'var(--lh-display)',
  };
  const subStyle = {
    fontSize: 'var(--fz-6)',
    fontFamily: 'var(--font-body)',
    color: tone === 'dark' ? 'var(--text-on-dark-mid)' : 'var(--text-muted)',
    maxWidth: maxSubWidth,
    margin: align === 'center' ? '0 auto' : undefined,
  };
  return React.createElement(
    'div', { className: 'syn-section-heading', style: wrap },
    label ? React.createElement('div', { style: labelStyle }, label) : null,
    title ? React.createElement('h2', { style: titleStyle }, title) : null,
    sub   ? React.createElement('p',  { style: subStyle }, sub) : null,
    children
  );
}
