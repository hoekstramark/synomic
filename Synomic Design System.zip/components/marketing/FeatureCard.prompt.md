Synomic's icon-led tile. Renders as `IconTile → h3 → p` inside a default Card.

```jsx
<FeatureCard icon="🎯" title="Resultaatgericht">
  Geen eindeloze analyses, maar concrete uitkomsten die direct waarde toevoegen.
</FeatureCard>
```

Pass `href` to make the whole card a link.
