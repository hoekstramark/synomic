Horizontal partner card. Drop a row of these inside a `background: var(--color-off-1)` strip.

```jsx
<PartnerPill logo="assets/partners/claude.png" name="Claude AI"  role="Kunstmatige intelligentie" href="partners.html" />
<PartnerPill logo="assets/partners/n8n.svg"    name="n8n"        role="Workflow automatisering" />
<PartnerPill logo="assets/partners/moneybird.png" name="Moneybird" role="Finance administratie" />
```
