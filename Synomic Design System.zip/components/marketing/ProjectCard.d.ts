import * as React from 'react';

/**
 * Case-study tile: navy gradient hero with emoji, category Tag, H3, body and tech-stack row.
 */
export interface ProjectCardProps {
  /** Single large emoji rendered on the navy hero block. */
  icon?: React.ReactNode;
  /** Top tag e.g. "Finance", "AI". */
  category?: React.ReactNode;
  title?: React.ReactNode;
  children?: React.ReactNode;
  /** Tech-stack chips, joined with · dots. */
  stack?: React.ReactNode[];
  style?: React.CSSProperties;
}

export function ProjectCard(props: ProjectCardProps): JSX.Element;
