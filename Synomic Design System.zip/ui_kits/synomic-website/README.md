# Synomic website — UI kit

A faithful but presentational recreation of [synomic.nl](https://synomic.nl), reassembled entirely from the design-system components.

## Files

- `index.html` — entry point. Loads React, the DS bundle, then `screens.jsx` and `app.jsx`.
- `screens.jsx` — one component per page (Home, About, Services, Projects, Partners, Contact) attached to `window.SynomicSiteScreens`. All UI is composed from the design system — no bespoke layouts.
- `app.jsx` — hash-router that swaps screens on `location.hash` changes.

## Pages covered

| Route | Component | Notes |
|---|---|---|
| `#/home`      | `HomeScreen`     | Hero, three-service grid, partner strip, closing CTA banner |
| `#/over-ons`  | `AboutScreen`    | Dark KVK stat panel, four core-value cards |
| `#/diensten`  | `ServicesScreen` | Four alternating service rows with checkmark lists |
| `#/projecten` | `ProjectsScreen` | Filterable grid of six case-study cards |
| `#/partners`  | `PartnersScreen` | Three partner cards (Claude, n8n, Moneybird) |
| `#/contact`   | `ContactScreen`  | Info column + working contact form (client-side validation) |

## Working interactions

- Nav links across all screens drive the hash router.
- `ProjectsScreen` filter buttons swap the visible cards.
- `ContactScreen` form validates fields, displays inline errors, and shows the success card on a clean submit.

## What's intentionally NOT here

- The animated canvas widgets (`#diagram-canvas`, finance bar chart, IT topology) from the live site. They're brand-specific decoration; recreating them adds bulk without changing how the design system composes.
- The Formspree contact-form integration — the form fakes submission instead.
- The scroll-shadow on the nav and the IntersectionObserver reveal animations. Easy to add back in a real consumer — the CSS hooks (`.is-scrolled`, `.reveal`) ship with the design system.
