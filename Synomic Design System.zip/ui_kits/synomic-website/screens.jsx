// Synomic website — UI kit screens.
// Single file because screens aren't shared elsewhere; they're each a
// faithful (but presentational) recreation of one page of synomic.nl.
//
// All screens consume components from window.SynomicDesignSystem_d4bf5f.
// The router (App) lives in app.jsx.

const ns = window.SynomicDesignSystem_d4bf5f;
const {
  Hero, SectionHeading, FeatureCard, PartnerPill, ProjectCard, CTABanner,
  NavBar, Footer, PageHeader, Card, Button, Tag, IconTile, Stat,
  TextField, Select, Checkbox,
} = ns;

const ASSET = (p) => '../../assets/' + p;
const NAV_ITEMS = [
  { href: '#/home',      label: 'Home' },
  { href: '#/over-ons',  label: 'Over ons' },
  { href: '#/diensten',  label: 'Diensten' },
  { href: '#/projecten', label: 'Projecten' },
  { href: '#/partners',  label: 'Partners' },
];
const NAV_CTA = { href: '#/contact', label: 'Contact' };

const Section = ({ children, alt, dark, style }) => (
  <section style={{
    padding: '80px 6vw',
    background: dark ? 'var(--surface-dark)' : alt ? 'var(--color-off-2)' : 'transparent',
    color: dark ? 'var(--text-on-dark)' : undefined,
    ...style,
  }}>{children}</section>
);

// ===== HOME =====
const HomeScreen = () => (
  <>
    <NavBar tone="dark" active="#/home" logoSrc={ASSET('logo-white.png')} items={NAV_ITEMS} cta={NAV_CTA} />
    <Hero
      badge="Finance · IT · AI Automatisering"
      title="Slimme oplossingen voor"
      cyanWord="digitale groei"
      intro="Technologie die werkt voor mensen, niet andersom. Synomic automatiseert, verbindt en optimaliseert — zodat bedrijven kunnen groeien zonder te verzanden in complexiteit."
      primary={{ href: '#/diensten', label: 'Bekijk diensten' }}
      secondary={{ href: '#/contact', label: 'Neem contact op' }}
    />

    <Section>
      <SectionHeading
        label="Wie zijn wij"
        title={<>Verbinden van technologie<br/>en bedrijfsvoering</>}
        sub="Synomic combineert finance, IT en AI-automatisering om bedrijven efficiënter te laten werken. Met een nuchtere Friese aanpak worden complexe vraagstukken vertaald naar praktische oplossingen die direct resultaat opleveren — zonder overbodige complexiteit."
        maxSubWidth={620}
      />
      <p style={{color:'var(--text-muted)', marginTop:-24, marginBottom:48, maxWidth:680, fontFamily:'var(--font-body)'}}>
        Achter de naam schuilt een heldere visie. <strong>Sync</strong> staat voor synchronisatie: systemen, processen en mensen die naadloos samenwerken. <strong>Nomic</strong> komt van economic — de economische waarde die vrijkomt wanneer een organisatie echt op orde is.
      </p>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'var(--gap-cards)'}}>
        <FeatureCard icon="📊" title="Finance & Data">
          Van finance rapportages tot dashboards: inzicht in de cijfers als fundament voor betere beslissingen.
        </FeatureCard>
        <FeatureCard icon="⚙️" title="IT & Automatisering">
          Processen stroomlijnen, systemen koppelen en handmatig werk elimineren — zodat het team zich focust op wat telt.
        </FeatureCard>
        <FeatureCard icon="🤖" title="AI Toepassingen">
          Praktische AI-implementaties die direct waarde leveren: van slimme analyses tot geautomatiseerde workflows.
        </FeatureCard>
      </div>
    </Section>

    <div style={{padding:'48px 6vw',background:'var(--color-off-1)',borderTop:'1px solid var(--border-soft)',borderBottom:'1px solid var(--border-soft)'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:28,flexWrap:'wrap',gap:12}}>
        <span style={{fontSize:'.75rem',fontWeight:700,letterSpacing:'.14em',textTransform:'uppercase',color:'var(--text-muted)'}}>Technologieën & tools</span>
        <a href="#/partners" style={{fontSize:'.88rem',fontWeight:700,color:'var(--color-navy)'}}>Bekijk alle partners →</a>
      </div>
      <div style={{display:'flex',gap:16,flexWrap:'wrap'}}>
        <PartnerPill logo={ASSET('partners/claude.png')} name="Claude AI" role="Kunstmatige intelligentie" href="#/partners" />
        <PartnerPill logo={ASSET('partners/n8n.svg')} name="n8n" role="Workflow automatisering" href="#/partners" />
        <PartnerPill logo={ASSET('partners/moneybird.png')} name="Moneybird" role="Finance administratie" href="#/partners" />
      </div>
    </div>

    <Section style={{padding:'0 6vw 80px'}}>
      <div style={{marginTop:80}}>
        <CTABanner
          eyebrow="Klaar voor de volgende stap?"
          title="Samen bouwen aan een digitale toekomst"
          cta={{ href: '#/contact', label: 'Start een gesprek →' }}
        />
      </div>
    </Section>

    <Footer logoSrc={ASSET('logo-white.png')} />
  </>
);

// ===== OVER ONS =====
const AboutScreen = () => (
  <>
    <NavBar active="#/over-ons" logoSrc={ASSET('logo.png')} items={NAV_ITEMS} cta={NAV_CTA} />
    <PageHeader
      title="Over"
      cyanWord="Synomic"
      breadcrumb={[{ href: '#/home', label: 'Home' }, { label: 'Over ons' }]}
      intro="Leer meer over de visie, aanpak en drijfveren achter Synomic."
    />

    <Section>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:64,alignItems:'center'}}>
        <div>
          <SectionHeading
            label="Het verhaal"
            title="Verbinden van werelden"
            sub={null}
            style={{marginBottom:20}}
          />
          <p style={{color:'var(--text-muted)',marginBottom:20,fontFamily:'var(--font-body)'}}>
            Synomic is opgericht vanuit de overtuiging dat de combinatie van financiële kennis, IT-expertise en AI-inzicht organisaties echt verder helpt. Niet met complexe theorieën, maar met praktische, meetbare resultaten.
          </p>
          <p style={{color:'var(--text-muted)',marginBottom:32,fontFamily:'var(--font-body)'}}>
            Synomic werkt nauw samen met opdrachtgevers — van startups tot gevestigde MKB-bedrijven — om processen slimmer in te richten, datagedreven beslissingen mogelijk te maken en technologie écht te laten werken voor de organisatie.
          </p>
          <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
            <Tag>Finance</Tag><Tag>IT</Tag><Tag>AI</Tag>
            <Tag>Automatisering</Tag><Tag>Data-analyse</Tag>
          </div>
        </div>
        <Card variant="dark">
          <div style={{fontSize:'2.8rem',fontFamily:'var(--font-display)',fontWeight:800,color:'var(--color-cyan)',marginBottom:28}}>Synomic</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:24}}>
            <Stat n="ZZP & MKB" label="Doelgroep" />
            <Stat n="30" accent="+" label="Projecten" />
            <Stat n="Nederland" label="Gevestigd" />
            <Stat n="NL · BE · PL" label="Actief in" />
          </div>
        </Card>
      </div>
    </Section>

    <Section alt>
      <SectionHeading
        label="Waar Synomic voor staat"
        title="Kernwaarden"
        sub="Elke opdracht wordt uitgevoerd vanuit dezelfde principes."
        align="center"
      />
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'var(--gap-cards)'}}>
        <FeatureCard icon="🎯" title="Resultaatgericht">
          Geen eindeloze analyses, maar concrete uitkomsten die direct waarde toevoegen aan de organisatie.
        </FeatureCard>
        <FeatureCard icon="🔗" title="Verbindend">
          Synomic brengt technologie en business samen. Jargon wordt vertaald naar begrijpelijke taal en haalbare stappen.
        </FeatureCard>
        <FeatureCard icon="💡" title="Innovatief">
          Synomic blijft continu op de hoogte van de nieuwste ontwikkelingen in AI en automatisering om de beste oplossingen te bieden.
        </FeatureCard>
        <FeatureCard icon="🤝" title="Betrokken">
          Het succes van de opdrachtgever staat centraal. Synomic investeert in een langdurige samenwerking en denkt proactief mee.
        </FeatureCard>
      </div>
    </Section>

    <Section>
      <div style={{maxWidth:600,margin:'0 auto',textAlign:'center'}}>
        <SectionHeading label="Bedrijfsgegevens" title="Synomic" align="center" sub={null} />
        <div style={{background:'var(--color-off-2)',borderRadius:'var(--radius-2xl)',padding:36,marginTop:32,textAlign:'left'}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
            {[
              ['Bedrijfsnaam','Synomic'],
              ['KVK-nummer','94705569'],
              ['Adres', <>Koornbeursweg 73<br/>8442 DJ Heerenveen</>],
              ['Specialisaties','Finance, IT, AI'],
            ].map(([k,v],i)=>(
              <div key={i}>
                <div style={{fontSize:'.78rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'.08em',marginBottom:4,fontFamily:'var(--font-body)'}}>{k}</div>
                <div style={{fontWeight:600,fontFamily:'var(--font-body)'}}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Section>

    <Footer logoSrc={ASSET('logo-white.png')} />
  </>
);

// ===== DIENSTEN =====
const DIENSTEN = [
  { n: '01', title: 'Finance & Data-analyse', icon: '📊',
    intro: 'Finance data is de ruggengraat van elke organisatie. Synomic structureert, visualiseert en vertaalt die data naar bruikbare inzichten voor management en bestuur.',
    items: ['Financiële dashboards & rapportages','Budgettering & forecasting','Business Intelligence (Power BI / Excel)','KPI-analyse & prestatiebeheer']},
  { n: '02', title: 'IT & Automatisering', icon: '⚙️',
    intro: 'Handmatige processen kosten tijd en geld. Synomic analyseert werkprocessen en implementeert slimme automatiseringen die direct resultaat opleveren.',
    items: ['Procesautomatisering (RPA / scripts)','Systeemintegraties & API-koppelingen','Cloud-migratie & infrastructuur','Softwareselectie & implementatiebegeleiding']},
  { n: '03', title: 'AI Toepassingen', icon: '🤖',
    intro: 'Kunstmatige intelligentie biedt enorme kansen, maar vraagt om een pragmatische aanpak. Synomic zet AI zinvol in — geen hype, maar concrete toepassingen die werken.',
    items: ['AI-strategie & implementatieadvies','Predictieve modellen & forecasting','Geautomatiseerde documentverwerking','LLM-integraties & chatbot-oplossingen']},
  { n: '04', title: 'Procesoptimalisatie', icon: '🔄',
    intro: 'Vaak zit verbetering al in de huidige processen, maar is die nog niet zichtbaar. Synomic brengt processen in kaart, identificeert knelpunten en implementeert verbeteringen.',
    items: ['Procesinventarisatie & -analyse (BPMN)','Lean / Six Sigma aanpak','Change management & adoptie','Continue verbetering & monitoring']},
];

const DienstRow = ({ d, reverse }) => {
  const visual = (
    <div style={{background:'var(--gradient-hero)',borderRadius:'var(--radius-3xl)',minHeight:260,display:'flex',alignItems:'center',justifyContent:'center',fontSize:'5rem',color:'#fff'}}>
      {d.icon}
    </div>
  );
  const text = (
    <div>
      <Tag style={{marginBottom:16}}>Dienst {d.n}</Tag>
      <h3 style={{fontFamily:'var(--font-display)',fontSize:'var(--fz-h3-l)',fontWeight:700,marginBottom:16,marginTop:0,color:'var(--text-strong)'}}>{d.title}</h3>
      <p style={{color:'var(--text-muted)',marginBottom:20,fontFamily:'var(--font-body)'}}>{d.intro}</p>
      <ul style={{listStyle:'none',display:'flex',flexDirection:'column',gap:10,padding:0,margin:0}}>
        {d.items.map((it,i)=>(
          <li key={i} style={{display:'flex',gap:10,alignItems:'flex-start',fontFamily:'var(--font-body)'}}>
            <span style={{color:'var(--color-cyan)',fontWeight:700,marginTop:1}}>✓</span>
            <span style={{color:'var(--text-muted)'}}>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
  return (
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:60,alignItems:'center',marginBottom:80}}>
      {reverse ? <>{text}{visual}</> : <>{visual}{text}</>}
    </div>
  );
};

const ServicesScreen = () => (
  <>
    <NavBar active="#/diensten" logoSrc={ASSET('logo.png')} items={NAV_ITEMS} cta={NAV_CTA} />
    <PageHeader
      title="Wat ik voor u"
      cyanWord="doe"
      breadcrumb={[{ href: '#/home', label: 'Home' }, { label: 'Diensten' }]}
      intro="Een overzicht van diensten op het snijvlak van finance, IT en AI-automatisering."
    />
    <Section>
      <SectionHeading
        label="Specialisaties"
        title="Core Competencies"
        sub="Iedere opdracht is uniek. De aanpak wordt afgestemd op de specifieke uitdaging, organisatie en doelstellingen."
        align="center"
        maxSubWidth={580}
      />
      {DIENSTEN.map((d,i)=> <DienstRow key={i} d={d} reverse={i%2===1} />)}
    </Section>
    <Section alt>
      <CTABanner
        eyebrow="Samen starten"
        title="Interesse in samenwerking?"
        cta={{ href: '#/contact', label: 'Stuur een bericht →' }}
      />
    </Section>
    <Footer logoSrc={ASSET('logo-white.png')} />
  </>
);

// ===== PROJECTEN =====
const PROJECTS = [
  { cat:'finance', tag:'Finance', icon:'📊', title:'Financieel dashboard MKB',
    desc:"Real-time Power BI dashboard gekoppeld aan boekhoudpakket. Management heeft nu altijd up-to-date inzicht in kasstromen, marges en KPI's.",
    stack:['Power BI','Excel','API-koppeling']},
  { cat:'it', tag:'IT Automatisering', icon:'⚙️', title:'Factuurverwerking geautomatiseerd',
    desc:'Handmatige factuurverwerking geautomatiseerd met Python en OCR. Verwerkingstijd teruggebracht van 3 uur naar 10 minuten per dag.',
    stack:['Python','OCR','RPA']},
  { cat:'ai', tag:'AI', icon:'🤖', title:'AI-assistent voor klantenservice',
    desc:'Geïmplementeerde AI-chatbot die 60% van terugkerende vragen zelfstandig beantwoordt, gekoppeld aan interne kennisbank.',
    stack:['LLM','RAG','Integratie']},
  { cat:'finance', tag:'Finance', icon:'📈', title:'Forecasting-model retail',
    desc:'Machine learning model voor omzetvoorspelling met 94% nauwkeurigheid. Helpt bij inkoop- en personeelsplanning.',
    stack:['Python','ML','Visualisatie']},
  { cat:'it', tag:'IT Automatisering', icon:'🔗', title:'Systeemintegratie ERP & CRM',
    desc:'Tweerichtingsintegratie tussen ERP en CRM opgezet. Dubbele invoer geëlimineerd, datakwaliteit verbeterd met 40%.',
    stack:['REST API','Middleware','ERP/CRM']},
  { cat:'ai', tag:'AI', icon:'🔍', title:'Slimme documentanalyse',
    desc:'AI-gedreven tool voor het automatisch extraheren en samenvatten van contracten en rapporten — tijdsbesparing van 70%.',
    stack:['NLP','Document AI','Python']},
];

const FilterBtn = ({active, onClick, children}) => (
  <button
    onClick={onClick}
    style={{
      padding: '9px 22px',
      borderRadius: 'var(--radius-pill)',
      border: '1.5px solid var(--border-default)',
      background: active ? 'var(--color-navy)' : 'var(--surface-card)',
      color: active ? 'var(--text-on-dark)' : 'var(--text-strong)',
      fontFamily: 'var(--font-body)', fontSize: '.88rem', fontWeight: 600,
      cursor: 'pointer',
      borderColor: active ? 'var(--color-navy)' : 'var(--border-default)',
      transition: 'background var(--dur-fast), color var(--dur-fast)',
    }}
  >{children}</button>
);

const ProjectsScreen = () => {
  const [cat, setCat] = React.useState('all');
  const visible = PROJECTS.filter(p => cat === 'all' || p.cat === cat);
  return (
    <>
      <NavBar active="#/projecten" logoSrc={ASSET('logo.png')} items={NAV_ITEMS} cta={NAV_CTA} />
      <PageHeader
        title="Projecten &"
        cyanWord="Cases"
        breadcrumb={[{ href: '#/home', label: 'Home' }, { label: 'Projecten' }]}
        intro="Een selectie van opdrachten en resultaten die laten zien wat Synomic voor de organisatie kan betekenen."
      />
      <Section>
        <div style={{display:'flex',gap:12,flexWrap:'wrap',justifyContent:'center',marginBottom:48}}>
          <FilterBtn active={cat==='all'} onClick={()=>setCat('all')}>Alle projecten</FilterBtn>
          <FilterBtn active={cat==='finance'} onClick={()=>setCat('finance')}>Finance</FilterBtn>
          <FilterBtn active={cat==='it'} onClick={()=>setCat('it')}>IT & Automatisering</FilterBtn>
          <FilterBtn active={cat==='ai'} onClick={()=>setCat('ai')}>AI</FilterBtn>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:'var(--gap-cards)'}}>
          {visible.map((p,i)=>(
            <ProjectCard key={i} icon={p.icon} category={p.tag} title={p.title} stack={p.stack}>
              {p.desc}
            </ProjectCard>
          ))}
        </div>
      </Section>
      <Section alt>
        <div style={{maxWidth:640,margin:'0 auto',textAlign:'center'}}>
          <SectionHeading label="Uw project" title={<>Wat kan Synomic<br/>voor organisaties betekenen?</>} align="center" sub="Elk project begint met een gesprek. Beschrijf de uitdaging en ontdek wat mogelijk is." />
          <Button href="#/contact">Neem contact op →</Button>
        </div>
      </Section>
      <Footer logoSrc={ASSET('logo-white.png')} />
    </>
  );
};

// ===== CONTACT =====
const ContactScreen = () => {
  const [submitted, setSubmitted] = React.useState(false);
  const [err, setErr] = React.useState({});
  const submit = (e) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const next = {};
    if (!f.get('naam') || f.get('naam').length < 2) next.naam = 'Naam invullen (minimaal 2 tekens).';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.get('email') || '')) next.email = 'Geldig e-mailadres invullen.';
    if (!f.get('onderwerp')) next.onderwerp = 'Selecteer een onderwerp.';
    if (!f.get('bericht') || f.get('bericht').length < 20) next.bericht = 'Beschrijf de vraag (minimaal 20 tekens).';
    if (!f.get('privacy')) next.privacy = 'U dient akkoord te gaan met de privacyverklaring.';
    setErr(next);
    if (Object.keys(next).length === 0) setSubmitted(true);
  };
  return (
    <>
      <NavBar active="#/contact" logoSrc={ASSET('logo.png')} items={NAV_ITEMS} cta={null} />
      <PageHeader
        title="Neem"
        cyanWord="contact op"
        breadcrumb={[{ href: '#/home', label: 'Home' }, { label: 'Contact' }]}
        intro="Heeft u een vraag of wilt u een vrijblijvend gesprek? Berichten worden binnen 1 werkdag beantwoord."
      />
      <Section>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1.4fr',gap:60,alignItems:'start'}}>
          <div>
            <SectionHeading label="Bereikbaarheid" title="Neem contact op" sub="Iedere samenwerking begint met een goed gesprek. Beschrijf de uitdaging en Synomic denkt graag mee — geheel vrijblijvend." />
            {[
              {icon:'📍',title:'Adres',body:'Koornbeursweg 73, 8442 DJ Heerenveen'},
              {icon:'💬',title:'Contact',body:'Via het contactformulier'},
              {icon:'⏰',title:'Reactietijd',body:'Binnen 1 werkdag'},
            ].map((c,i)=>(
              <div key={i} style={{display:'flex',alignItems:'flex-start',gap:16,marginBottom:24}}>
                <IconTile size="sm">{c.icon}</IconTile>
                <div>
                  <strong style={{display:'block',fontFamily:'var(--font-display)',fontSize:'.9rem',marginBottom:2,color:'var(--text-strong)'}}>{c.title}</strong>
                  <span style={{fontSize:'.9rem',color:'var(--text-muted)',fontFamily:'var(--font-body)'}}>{c.body}</span>
                </div>
              </div>
            ))}
            <div style={{marginTop:40,padding:24,background:'var(--color-off-2)',borderRadius:14}}>
              <div style={{fontFamily:'var(--font-display)',fontWeight:700,fontSize:'.9rem',marginBottom:14,color:'var(--text-strong)'}}>Veilig en vertrouwd</div>
              <ul style={{listStyle:'none',display:'flex',flexDirection:'column',gap:8,padding:0,margin:0}}>
                <li style={{display:'flex',gap:10,alignItems:'center',fontSize:'.88rem',color:'var(--text-muted)',fontFamily:'var(--font-body)'}}>
                  <span style={{color:'var(--color-cyan)',fontSize:'1rem'}}>🔒</span> Uw gegevens worden nooit gedeeld met derden
                </li>
                <li style={{display:'flex',gap:10,alignItems:'center',fontSize:'.88rem',color:'var(--text-muted)',fontFamily:'var(--font-body)'}}>
                  <span style={{color:'var(--color-cyan)',fontSize:'1rem'}}>✉️</span> Versleuteld contactformulier
                </li>
              </ul>
            </div>
          </div>
          <div>
            <Card variant="form" interactive={false}>
              {submitted ? (
                <div style={{display:'flex',gap:12,alignItems:'center',padding:20,background:'var(--cyan-10)',border:'1.5px solid var(--color-cyan)',borderRadius:12}}>
                  <span style={{fontSize:'1.5rem'}}>✅</span>
                  <div>
                    <strong style={{fontFamily:'var(--font-display)',color:'var(--text-strong)'}}>Bericht verzonden!</strong><br/>
                    <span style={{fontSize:'.9rem',color:'var(--text-muted)',fontFamily:'var(--font-body)'}}>Bedankt voor uw bericht. Ik neem zo snel mogelijk contact met u op, uiterlijk binnen 1 werkdag.</span>
                  </div>
                </div>
              ) : (
                <form onSubmit={submit} noValidate>
                  <h3 style={{marginBottom:6,fontSize:'var(--fz-h3)',fontFamily:'var(--font-display)',fontWeight:700,color:'var(--text-strong)'}}>Stuur een bericht</h3>
                  <p style={{color:'var(--text-muted)',fontSize:'.9rem',marginBottom:28,fontFamily:'var(--font-body)'}}>Alle velden met <span style={{color:'var(--color-cyan)'}}>*</span> zijn verplicht.</p>

                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
                    <TextField id="naam" name="naam" label="Naam" required placeholder="Jan de Vries" error={err.naam} />
                    <TextField id="bedrijf" name="bedrijf" label="Bedrijf" optional placeholder="Bedrijfsnaam (optioneel)" />
                  </div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
                    <TextField id="email" name="email" label="E-mailadres" required type="email" placeholder="jan@bedrijf.nl" autoComplete="email" error={err.email} />
                    <TextField id="telefoon" name="telefoon" label="Telefoonnummer" optional type="tel" placeholder="+31 6 12345678" />
                  </div>
                  <Select
                    id="onderwerp" name="onderwerp" label="Onderwerp" required
                    options={[
                      {value:'finance',label:'Finance & Data-analyse'},
                      {value:'it',     label:'IT & Automatisering'},
                      {value:'ai',     label:'AI Toepassingen'},
                      {value:'proces', label:'Procesoptimalisatie'},
                      {value:'anders', label:'Overig'},
                    ]}
                    placeholder="Selecteer een onderwerp..."
                    error={err.onderwerp}
                  />
                  <TextField id="bericht" name="bericht" label="Bericht" required multiline placeholder="Beschrijf kort de vraag of uitdaging..." error={err.bericht} />
                  <div style={{marginTop:6,marginBottom:18}}>
                    <Checkbox id="privacy" name="privacy" required
                      label={<>Ik ga akkoord met het verwerken van mijn gegevens voor het beantwoorden van mijn vraag. Synomic deelt uw gegevens nooit met derden.</>}
                      error={err.privacy}
                    />
                  </div>
                  <Button as="button" type="submit" style={{width:'100%',background:'var(--color-navy)'}}>Verstuur bericht</Button>
                  <p style={{display:'flex',gap:6,alignItems:'center',justifyContent:'center',fontSize:'.78rem',color:'var(--text-muted)',marginTop:14,fontFamily:'var(--font-body)'}}>
                    🔒 Dit formulier is beveiligd. Uw gegevens worden vertrouwelijk behandeld.
                  </p>
                </form>
              )}
            </Card>
          </div>
        </div>
      </Section>
      <Footer logoSrc={ASSET('logo-white.png')} />
    </>
  );
};

// ===== PARTNERS =====
const PartnersScreen = () => (
  <>
    <NavBar active="#/partners" logoSrc={ASSET('logo.png')} items={NAV_ITEMS} cta={NAV_CTA} />
    <PageHeader
      title="Partners &"
      cyanWord="tools"
      breadcrumb={[{ href: '#/home', label: 'Home' }, { label: 'Partners' }]}
      intro="De gereedschapskist achter Synomic — partners en integraties die in opdrachten worden ingezet."
    />
    <Section>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:'var(--gap-cards)'}}>
        {[
          {logo:ASSET('partners/claude.png'),name:'Claude AI',role:'Kunstmatige intelligentie',body:'Synomic werkt met Claude voor doc-extractie, prompt-engineering en het bouwen van betrouwbare LLM-pipelines.'},
          {logo:ASSET('partners/n8n.svg'),name:'n8n',role:'Workflow automatisering',body:'Synomic gebruikt n8n voor self-hosted automatiseringen die meerdere systemen aan elkaar knopen zonder vendor lock-in.'},
          {logo:ASSET('partners/moneybird.png'),name:'Moneybird',role:'Finance administratie',body:'Synomic koppelt Moneybird aan dashboards en triggers in n8n zodat finance-data direct bruikbaar wordt.'},
        ].map((p,i)=>(
          <Card key={i} style={{display:'flex',flexDirection:'column',gap:18}}>
            <div style={{width:64,height:64,borderRadius:'var(--radius-md)',background:'#fff',border:'1px solid var(--border-soft)',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <img src={p.logo} alt={p.name} style={{width:42,height:42,objectFit:'contain'}} />
            </div>
            <div>
              <h3 style={{fontFamily:'var(--font-display)',fontSize:'var(--fz-h4)',fontWeight:700,marginBottom:4,color:'var(--text-strong)'}}>{p.name}</h3>
              <div style={{fontSize:'.78rem',color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'.08em',fontWeight:600,fontFamily:'var(--font-body)'}}>{p.role}</div>
            </div>
            <p style={{color:'var(--text-muted)',fontSize:'.95rem',fontFamily:'var(--font-body)'}}>{p.body}</p>
          </Card>
        ))}
      </div>
    </Section>
    <Footer logoSrc={ASSET('logo-white.png')} />
  </>
);

window.SynomicSiteScreens = { HomeScreen, AboutScreen, ServicesScreen, ProjectsScreen, ContactScreen, PartnersScreen };
