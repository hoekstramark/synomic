// Synomic website — top-level router.
// Reads window.location.hash and renders one of the screens defined in screens.jsx.

const { HomeScreen, AboutScreen, ServicesScreen, ProjectsScreen, ContactScreen, PartnersScreen } = window.SynomicSiteScreens;

const ROUTES = {
  '#/home':      HomeScreen,
  '#/over-ons':  AboutScreen,
  '#/diensten':  ServicesScreen,
  '#/projecten': ProjectsScreen,
  '#/contact':   ContactScreen,
  '#/partners':  PartnersScreen,
};

function App() {
  const [route, setRoute] = React.useState(window.location.hash || '#/home');
  React.useEffect(() => {
    const onHash = () => { setRoute(window.location.hash || '#/home'); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const Screen = ROUTES[route] || HomeScreen;
  return <Screen />;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
